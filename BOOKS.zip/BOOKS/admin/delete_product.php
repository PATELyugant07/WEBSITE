<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Get product ID from URL
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($product_id <= 0) {
    header('Location: products.php');
    exit;
}

// Get product data
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: products.php');
    exit;
}

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    try {
        // Delete the product image file
        if ($product['image'] && file_exists('../uploads/' . $product['image'])) {
            deleteImage($product['image']);
        }
        
        // Delete from database
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        
        // Redirect with success message
        header('Location: products.php?deleted=1');
        exit;
        
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Product - The Book Brief: web services Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
        }
        .product-image {
            max-width: 200px;
            max-height: 200px;
            border-radius: 8px;
            border: 2px solid #dee2e6;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h4 class="text-white">
                            <i class="fas fa-fire"></i> The Book Brief: web services
                        </h4>
                        <p class="text-white-50">Admin Panel</p>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="products.php">
                                <i class="fas fa-box"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="add_product.php">
                                <i class="fas fa-plus"></i> Add Product
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="categories.php">
                                <i class="fas fa-tags"></i> Categories
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="text-white-50">
                    
                    <div class="text-center">
                        <a href="../index.php" class="btn btn-outline-light btn-sm">
                            <i class="fas fa-external-link-alt"></i> View Store
                        </a>
                    </div>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Delete Product</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="products.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Products
                        </a>
                    </div>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-danger" role="alert">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <div class="card shadow border-danger">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-exclamation-triangle"></i> Confirm Product Deletion
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="alert alert-warning" role="alert">
                                    <h6><i class="fas fa-warning"></i> Warning!</h6>
                                    <p class="mb-0">You are about to permanently delete the product "<strong><?php echo htmlspecialchars($product['name']); ?></strong>". This action cannot be undone.</p>
                                </div>

                                <h5>Product Details:</h5>
                                <table class="table table-borderless">
                                    <tr>
                                        <td><strong>Product ID:</strong></td>
                                        <td>#<?php echo $product['id']; ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Name:</strong></td>
                                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Category:</strong></td>
                                        <td><span class="badge bg-primary"><?php echo htmlspecialchars($product['category']); ?></span></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Price:</strong></td>
                                        <td><strong class="text-success">$<?php echo number_format($product['price'], 2); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Description:</strong></td>
                                        <td><?php echo htmlspecialchars($product['description']); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Image File:</strong></td>
                                        <td><?php echo htmlspecialchars($product['image']); ?></td>
                                    </tr>
                                </table>

                                <div class="alert alert-info" role="alert">
                                    <h6><i class="fas fa-info-circle"></i> What will be deleted:</h6>
                                    <ul class="mb-0">
                                        <li>Product record from database</li>
                                        <li>Product image file (<?php echo htmlspecialchars($product['image']); ?>)</li>
                                        <li>All associated data</li>
                                    </ul>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="text-center mb-3">
                                    <h6>Product Image:</h6>
                                    <img src="../uploads/<?php echo htmlspecialchars($product['image']); ?>" 
                                         alt="<?php echo htmlspecialchars($product['name']); ?>"
                                         class="product-image">
                                </div>

                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6 class="card-title">
                                            <i class="fas fa-question-circle"></i> Need Help?
                                        </h6>
                                        <p class="card-text small">
                                            If you're unsure about deleting this product, consider:
                                        </p>
                                        <ul class="card-text small">
                                            <li>Editing the product instead</li>
                                            <li>Setting it as inactive</li>
                                            <li>Moving it to a different category</li>
                                        </ul>
                                        <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-outline-primary btn-sm">
                                            <i class="fas fa-edit"></i> Edit Instead
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <form method="POST" class="d-flex justify-content-between">
                            <a href="products.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                            <button type="submit" name="confirm_delete" class="btn btn-danger" 
                                    onclick="return confirm('Are you absolutely sure you want to delete this product? This action cannot be undone.')">
                                <i class="fas fa-trash"></i> Delete Product Permanently
                            </button>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
