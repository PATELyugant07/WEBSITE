<?php
session_start();
require_once '../config/database.php';

// Check admin session
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
	header('Location: login.php');
	exit;
}

// Filters
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;

// Load products for filter
$products = [];
try {
	$stmt = $pdo->query('SELECT id, name FROM products ORDER BY name');
	$products = $stmt->fetchAll();
} catch (PDOException $e) {}

$customers = [];
$selectedProduct = null;

try {
	$params = [];
	$sql = "
		SELECT
			u.id as user_id,
			u.first_name,
			u.last_name,
			u.email,
			COALESCE(SUM(oi.quantity),0) as total_quantity,
			COALESCE(SUM(oi.quantity * oi.price),0) as total_spent,
			COUNT(DISTINCT o.id) as orders_count
		FROM users u
		JOIN orders o ON o.user_id = u.id
		JOIN order_items oi ON oi.order_id = o.id
		JOIN products p ON p.id = oi.product_id
	";
	if ($product_id > 0) {
		$sql .= " WHERE p.id = ?";
		$params[] = $product_id;
	}
	$sql .= "
		GROUP BY u.id, u.first_name, u.last_name, u.email
		HAVING total_quantity > 0
		ORDER BY total_spent DESC
	";
	$stmt = $pdo->prepare($sql);
	$stmt->execute($params);
	$customers = $stmt->fetchAll();

	if ($product_id > 0) {
		$st2 = $pdo->prepare('SELECT id, name FROM products WHERE id = ?');
		$st2->execute([$product_id]);
		$selectedProduct = $st2->fetch();
	}
} catch (PDOException $e) {
	$customers = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Customers - The Book Brief: web services Admin</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
	<style>
		.sidebar { min-height: 100vh; background: linear-gradient(135deg,#667eea 0%,#764ba2 100%); }
		.sidebar .nav-link { color: rgba(255,255,255,0.8); border-radius: 8px; margin: 2px 0; }
		.sidebar .nav-link:hover, .sidebar .nav-link.active { color:#fff; background: rgba(255,255,255,0.1); }
	</style>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<!-- Sidebar -->
			<nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
				<div class="position-sticky pt-3">
					<div class="text-center mb-4">
						<h4 class="text-white"><i class="fas fa-fire"></i> The Book Brief: web services</h4>
						<p class="text-white-50">Admin Panel</p>
					</div>
					<ul class="nav flex-column">
						<li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
						<li class="nav-item"><a class="nav-link" href="products.php"><i class="fas fa-box"></i> Products</a></li>
						<li class="nav-item"><a class="nav-link" href="add_product.php"><i class="fas fa-plus"></i> Add Product</a></li>
						<li class="nav-item"><a class="nav-link active" href="customers.php"><i class="fas fa-users"></i> Customers</a></li>
						<li class="nav-item"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
					</ul>
					<hr class="text-white-50">
					<div class="text-center">
						<a href="../index.php" class="btn btn-outline-light btn-sm"><i class="fas fa-external-link-alt"></i> View Store</a>
					</div>
				</div>
			</nav>

			<!-- Main -->
			<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
				<div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h2">Customers</h1>
				</div>

				<div class="card mb-3">
					<div class="card-body">
						<form method="GET" class="row g-3 align-items-end">
							<div class="col-md-6">
								<label class="form-label">Filter by Product</label>
								<select name="product_id" class="form-select">
									<option value="0">All Products</option>
									<?php foreach ($products as $p): ?>
										<option value="<?php echo $p['id']; ?>" <?php echo $product_id===$p['id']?'selected':''; ?>>
											<?php echo htmlspecialchars($p['name']); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
							<div class="col-md-3">
								<button class="btn btn-primary w-100"><i class="fas fa-filter"></i> Apply</button>
							</div>
							<div class="col-md-3 text-md-end">
								<button type="button" class="btn btn-outline-secondary w-100" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
							</div>
						</form>
					</div>
				</div>

				<div class="card">
					<div class="card-header d-flex justify-content-between align-items-center">
						<h5 class="mb-0">
							<i class="fas fa-users"></i> 
							<?php echo $product_id>0 && $selectedProduct ? 'Customers who bought: '.htmlspecialchars($selectedProduct['name']) : 'All Customers Who Purchased'; ?>
						</h5>
					</div>
					<div class="card-body">
						<?php if (empty($customers)): ?>
							<div class="text-center py-4 text-muted">No purchase records found.</div>
						<?php else: ?>
							<div class="table-responsive">
								<table class="table table-hover align-middle">
									<thead class="table-light">
										<tr>
											<th>Customer</th>
											<th>Email</th>
											<th class="text-end">Orders</th>
											<th class="text-end">Total Qty</th>
											<th class="text-end">Total Spent (₹)</th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ($customers as $c): ?>
											<tr>
												<td><?php echo htmlspecialchars($c['first_name'].' '.$c['last_name']); ?></td>
												<td><?php echo htmlspecialchars($c['email']); ?></td>
												<td class="text-end"><?php echo (int)$c['orders_count']; ?></td>
												<td class="text-end"><?php echo (int)$c['total_quantity']; ?></td>
												<td class="text-end"><?php echo number_format($c['total_spent'], 2); ?></td>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</main>
		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
