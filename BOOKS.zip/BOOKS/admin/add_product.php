<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = trim($_POST['price']);
    
    // Handle new category vs existing category
    $category = trim($_POST['category_new']) ?: trim($_POST['category']);
    
    // Validation
    if (empty($name)) {
        $errors[] = 'Product name is required.';
    }
    
    if (empty($description)) {
        $errors[] = 'Product description is required.';
    }
    
    if (empty($price) || !is_numeric($price) || $price <= 0) {
        $errors[] = 'Valid price is required.';
    }
    
    if (empty($category)) {
        $errors[] = 'Category is required.';
    }
    
    // Handle image upload
    $image_filename = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_validation = validateImageUpload($_FILES['image']);
        if ($image_validation === true) {
            $image_filename = uploadProductImage($_FILES['image'], $name);
            if (!$image_filename) {
                $errors[] = 'Failed to upload image. Please try again.';
            }
        } else {
            $errors[] = $image_validation;
        }
    } else {
        $errors[] = 'Product image is required.';
    }
    
    // If no errors, insert product
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO products (name, description, price, category, image) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $description, $price, $category, $image_filename]);
            
            $success = 'Product added successfully!';
            
            // Clear form data
            $name = $description = $price = $category = '';
            
        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }
}

// Get existing categories for dropdown
$cat_stmt = $pdo->query("SELECT DISTINCT category FROM products ORDER BY category");
$existing_categories = $cat_stmt->fetchAll(PDO::FETCH_COLUMN);

// Image upload functions
function validateImageUpload($file) {
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowedTypes)) {
        return 'Please upload a valid image file (JPG, PNG, or GIF).';
    }
    
    if ($file['size'] > $maxSize) {
        return 'Image file size must be less than 5MB.';
    }
    
    return true;
}

function uploadProductImage($file, $productName) {
    $uploadDir = '../uploads/';
    
    // Create directory if it doesn't exist
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Get file extension
    $fileInfo = pathinfo($file['name']);
    $extension = strtolower($fileInfo['extension']);
    
    // Create clean filename from product name
    $cleanName = strtolower($productName);
    $cleanName = preg_replace('/[^a-z0-9\s]/', '', $cleanName); // Remove special characters
    $cleanName = preg_replace('/\s+/', '_', trim($cleanName)); // Replace spaces with underscores
    $cleanName = substr($cleanName, 0, 30); // Limit length
    
    // Create unique filename
    $filename = $cleanName . '.' . $extension;
    $counter = 1;
    
    // Handle duplicate filenames
    while (file_exists($uploadDir . $filename)) {
        $filename = $cleanName . '_' . $counter . '.' . $extension;
        $counter++;
    }
    
    $targetPath = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return $filename;
    }
    
    return false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Candle Store Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
        }
        .image-preview {
            max-width: 200px;
            max-height: 200px;
            border-radius: 8px;
            border: 2px dashed #dee2e6;
        }
        .form-label {
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h4 class="text-white">
                            <i class="fas fa-fire"></i> The Book Brief: web services
                        </h4>
                        <p class="text-white-50">Admin Panel</p>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="products.php">
                                <i class="fas fa-box"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="add_product.php">
                                <i class="fas fa-plus"></i> Add Product
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="categories.php">
                                <i class="fas fa-tags"></i> Categories
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="text-white-50">
                    
                    <div class="text-center">
                        <a href="../index.php" class="btn btn-outline-light btn-sm">
                            <i class="fas fa-external-link-alt"></i> View Store
                        </a>
                    </div>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Add New Product</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="products.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Products
                        </a>
                    </div>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger" role="alert">
                        <h6><i class="fas fa-exclamation-triangle"></i> Please fix the following errors:</h6>
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if (!empty($success)): ?>
                    <div class="alert alert-success" role="alert">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php endif; ?>

                <div class="card shadow">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-plus-circle"></i> Product Information
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="mb-3">
                                        <label for="name" class="form-label">
                                            <i class="fas fa-tag"></i> Product Name *
                                        </label>
                                        <input type="text" class="form-control" id="name" name="name" 
                                               value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>" 
                                               required>
                                        <div class="form-text">Enter a descriptive name for the candle.</div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="description" class="form-label">
                                            <i class="fas fa-align-left"></i> Description *
                                        </label>
                                        <textarea class="form-control" id="description" name="description" rows="4" required><?php echo isset($description) ? htmlspecialchars($description) : ''; ?></textarea>
                                        <div class="form-text">Describe the scent, size, burn time, and other features.</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="price" class="form-label">
                                                    <i class="fas fa-dollar-sign"></i> Price *
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" class="form-control" id="price" name="price" 
                                                           step="0.01" min="0.01" 
                                                           value="<?php echo isset($price) ? htmlspecialchars($price) : ''; ?>" 
                                                           required>
                                                </div>
                                                <div class="form-text">Enter the price in rupees.</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="category" class="form-label">
                                                    <i class="fas fa-tags"></i> Existing Category
                                                </label>
                                                <select class="form-select" id="category" name="category">
                                                    <option value="">Select Existing Category</option>
                                                    <?php foreach ($existing_categories as $cat): ?>
                                                        <option value="<?php echo htmlspecialchars($cat); ?>" 
                                                                <?php echo (isset($category) && $category === $cat) ? 'selected' : ''; ?>>
                                                            <?php echo htmlspecialchars($cat); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="category_new" class="form-label">
                                            <i class="fas fa-plus"></i> Or Create New Category *
                                        </label>
                                        <input type="text" class="form-control" id="category_new" name="category_new"
                                               placeholder="Type to create a new category">
                                        <div class="form-text">Either select an existing category above OR enter a new category name.</div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="image" class="form-label">
                                            <i class="fas fa-image"></i> Product Image *
                                        </label>
                                        <input type="file" class="form-control" id="image" name="image" 
                                               accept="image/*" required>
                                        <div class="form-text">Upload a high-quality image (JPG, PNG, GIF, max 5MB).</div>
                                        
                                        <div class="mt-3">
                                            <img id="imagePreview" src="#" alt="Preview" class="image-preview d-none">
                                        </div>
                                    </div>

                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <h6 class="card-title">
                                                <i class="fas fa-info-circle"></i> Tips
                                            </h6>
                                            <ul class="card-text small">
                                                <li>Use descriptive product names</li>
                                                <li>Include scent details in description</li>
                                                <li>Upload clear, well-lit product photos</li>
                                                <li>Set competitive pricing</li>
                                                <li>Choose appropriate categories</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-between">
                                <a href="products.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-save"></i> Add Product
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Image preview
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const preview = document.getElementById('imagePreview');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.remove('d-none');
                }
                reader.readAsDataURL(file);
            } else {
                preview.classList.add('d-none');
            }
        });

        // Category handling
        document.getElementById('category_new').addEventListener('input', function(e) {
            const newCategory = e.target.value.trim();
            const categorySelect = document.getElementById('category');
            
            if (newCategory) {
                categorySelect.value = '';
            }
        });

        document.getElementById('category').addEventListener('change', function(e) {
            const selectedCategory = e.target.value;
            const newCategoryInput = document.getElementById('category_new');
            
            if (selectedCategory) {
                newCategoryInput.value = '';
            }
        });
    </script>
</body>
</html>
