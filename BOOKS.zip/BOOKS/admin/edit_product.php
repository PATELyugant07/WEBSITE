<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$errors = [];
$success = '';

// Get product ID from URL
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($product_id <= 0) {
    header('Location: products.php');
    exit;
}

// Get product data
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: products.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = trim($_POST['price']);
    $category = trim($_POST['category']);
    
    // Validation
    if (empty($name)) {
        $errors[] = 'Product name is required.';
    }
    
    if (empty($description)) {
        $errors[] = 'Product description is required.';
    }
    
    if (empty($price) || !is_numeric($price) || $price <= 0) {
        $errors[] = 'Valid price is required.';
    }
    
    if (empty($category)) {
        $errors[] = 'Category is required.';
    }
    
    // Handle image upload (optional for edit)
    $image_filename = $product['image']; // Keep existing image by default
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_validation = validateImage($_FILES['image']);
        if ($image_validation === true) {
            $new_image_filename = uploadImage($_FILES['image']);
            if ($new_image_filename) {
                // Delete old image if upload successful
                if ($image_filename && file_exists('../uploads/' . $image_filename)) {
                    deleteImage($image_filename);
                }
                $image_filename = $new_image_filename;
            } else {
                $errors[] = 'Failed to upload image. Please try again.';
            }
        } else {
            $errors[] = $image_validation;
        }
    }
    
    // If no errors, update product
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("UPDATE products SET name = ?, description = ?, price = ?, category = ?, image = ? WHERE id = ?");
            $stmt->execute([$name, $description, $price, $category, $image_filename, $product_id]);
            
            $success = 'Product updated successfully!';
            
            // Update product data for display
            $product['name'] = $name;
            $product['description'] = $description;
            $product['price'] = $price;
            $product['category'] = $category;
            $product['image'] = $image_filename;
            
        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }
}

// Get existing categories for dropdown
$cat_stmt = $pdo->query("SELECT DISTINCT category FROM products ORDER BY category");
$existing_categories = $cat_stmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - The Book Brief: web services Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
        }
        .image-preview {
            max-width: 200px;
            max-height: 200px;
            border-radius: 8px;
            border: 2px solid #dee2e6;
        }
        .current-image {
            max-width: 150px;
            max-height: 150px;
            border-radius: 8px;
            border: 2px solid #dee2e6;
        }
        .form-label {
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h4 class="text-white">
                            <i class="fas fa-fire"></i> The Book Brief: web services
                        </h4>
                        <p class="text-white-50">Admin Panel</p>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="products.php">
                                <i class="fas fa-box"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="add_product.php">
                                <i class="fas fa-plus"></i> Add Product
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="categories.php">
                                <i class="fas fa-tags"></i> Categories
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="text-white-50">
                    
                    <div class="text-center">
                        <a href="../index.php" class="btn btn-outline-light btn-sm">
                            <i class="fas fa-external-link-alt"></i> View Store
                        </a>
                    </div>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Edit Product</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="products.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Products
                        </a>
                    </div>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger" role="alert">
                        <h6><i class="fas fa-exclamation-triangle"></i> Please fix the following errors:</h6>
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if (!empty($success)): ?>
                    <div class="alert alert-success" role="alert">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php endif; ?>

                <div class="card shadow">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-edit"></i> Edit Product: <?php echo htmlspecialchars($product['name']); ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="mb-3">
                                        <label for="name" class="form-label">
                                            <i class="fas fa-tag"></i> Product Name *
                                        </label>
                                        <input type="text" class="form-control" id="name" name="name" 
                                               value="<?php echo htmlspecialchars($product['name']); ?>" 
                                               required>
                                        <div class="form-text">Enter a descriptive name for the candle.</div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="description" class="form-label">
                                            <i class="fas fa-align-left"></i> Description *
                                        </label>
                                        <textarea class="form-control" id="description" name="description" rows="4" required><?php echo htmlspecialchars($product['description']); ?></textarea>
                                        <div class="form-text">Describe the scent, size, burn time, and other features.</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="price" class="form-label">
                                                    <i class="fas fa-dollar-sign"></i> Price *
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text">$</span>
                                                    <input type="number" class="form-control" id="price" name="price" 
                                                           step="0.01" min="0.01" 
                                                           value="<?php echo htmlspecialchars($product['price']); ?>" 
                                                           required>
                                                </div>
                                                <div class="form-text">Enter the price in dollars.</div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="category" class="form-label">
                                                    <i class="fas fa-tags"></i> Category *
                                                </label>
                                                <select class="form-select" id="category" name="category" required>
                                                    <option value="">Select Category</option>
                                                    <?php foreach ($existing_categories as $cat): ?>
                                                        <option value="<?php echo htmlspecialchars($cat); ?>" 
                                                                <?php echo $product['category'] === $cat ? 'selected' : ''; ?>>
                                                            <?php echo htmlspecialchars($cat); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <div class="form-text">Choose an existing category or type a new one.</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="category_new" class="form-label">
                                            <i class="fas fa-plus"></i> New Category (Optional)
                                        </label>
                                        <input type="text" class="form-control" id="category_new" 
                                               placeholder="Type to create a new category">
                                        <div class="form-text">Leave empty to use selected category above.</div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="image" class="form-label">
                                            <i class="fas fa-image"></i> Product Image
                                        </label>
                                        <input type="file" class="form-control" id="image" name="image" 
                                               accept="image/*">
                                        <div class="form-text">Upload a new image to replace the current one (optional).</div>
                                        
                                        <div class="mt-3">
                                            <h6>Current Image:</h6>
                                            <img src="../uploads/<?php echo htmlspecialchars($product['image']); ?>" 
                                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                                 class="current-image">
                                        </div>
                                        
                                        <div class="mt-3">
                                            <h6>New Image Preview:</h6>
                                            <img id="imagePreview" src="#" alt="Preview" class="image-preview d-none">
                                        </div>
                                    </div>

                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <h6 class="card-title">
                                                <i class="fas fa-info-circle"></i> Product Info
                                            </h6>
                                            <ul class="card-text small">
                                                <li><strong>ID:</strong> #<?php echo $product['id']; ?></li>
                                                <li><strong>Current Price:</strong> $<?php echo number_format($product['price'], 2); ?></li>
                                                <li><strong>Category:</strong> <?php echo htmlspecialchars($product['category']); ?></li>
                                                <li><strong>Image:</strong> <?php echo htmlspecialchars($product['image']); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="d-flex justify-content-between">
                                <a href="products.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                                <div>
                                    <a href="delete_product.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-danger me-2"
                                       onclick="return confirm('Are you sure you want to delete this product? This action cannot be undone.')">
                                        <i class="fas fa-trash"></i> Delete Product
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save"></i> Update Product
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Image preview
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const preview = document.getElementById('imagePreview');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.remove('d-none');
                }
                reader.readAsDataURL(file);
            } else {
                preview.classList.add('d-none');
            }
        });

        // Category handling
        document.getElementById('category_new').addEventListener('input', function(e) {
            const newCategory = e.target.value.trim();
            const categorySelect = document.getElementById('category');
            
            if (newCategory) {
                // If user types in new category, clear the select
                categorySelect.value = '';
            }
        });

        document.getElementById('category').addEventListener('change', function(e) {
            const selectedCategory = e.target.value;
            const newCategoryInput = document.getElementById('category_new');
            
            if (selectedCategory) {
                // If user selects existing category, clear the new category input
                newCategoryInput.value = '';
            }
        });

        // Form submission handling
        document.querySelector('form').addEventListener('submit', function(e) {
            const newCategory = document.getElementById('category_new').value.trim();
            const selectedCategory = document.getElementById('category').value;
            
            if (newCategory && !selectedCategory) {
                // If new category is entered, set it as the category value
                const hiddenInput = document.createElement('input');
                hiddenInput.type = 'hidden';
                hiddenInput.name = 'category';
                hiddenInput.value = newCategory;
                this.appendChild(hiddenInput);
            }
        });
    </script>
</body>
</html>
