<?php
session_start();
require_once '../config/database.php';

$token = $_GET['token'] ?? '';
$error = '';
$success = '';
$valid = false;
$userType = null; $userId = null;

if ($token !== '') {
	$stmt = $pdo->prepare('SELECT * FROM password_resets WHERE token = ? AND used = 0 AND expires_at > NOW()');
	$stmt->execute([$token]);
	$row = $stmt->fetch();
	if ($row) { $valid = true; $userType = $row['user_type']; $userId = (int)$row['user_id']; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$token = $_POST['token'] ?? '';
	$new_password = $_POST['new_password'] ?? '';
	$confirm_password = $_POST['confirm_password'] ?? '';
	if ($new_password === '' || strlen($new_password) < 6) {
		$error = 'Password must be at least 6 characters.';
	} elseif ($new_password !== $confirm_password) {
		$error = 'Passwords do not match.';
	} else {
		// Validate token again
		$stmt = $pdo->prepare('SELECT * FROM password_resets WHERE token = ? AND used = 0 AND expires_at > NOW()');
		$stmt->execute([$token]);
		$row = $stmt->fetch();
		if (!$row) {
			$error = 'Invalid or expired reset link.';
		} else {
			try {
				$hash = password_hash($new_password, PASSWORD_DEFAULT);
				if ($row['user_type'] === 'user') {
					$upd = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
					$upd->execute([$hash, (int)$row['user_id']]);
				} else {
					$upd = $pdo->prepare('UPDATE admin_users SET password = ? WHERE id = ?');
					$upd->execute([$hash, (int)$row['user_id']]);
				}
				$mark = $pdo->prepare('UPDATE password_resets SET used = 1 WHERE id = ?');
				$mark->execute([(int)$row['id']]);
				$success = 'Password updated. You can now login.';
			} catch (PDOException $e) {
				$error = 'Failed to update password.';
			}
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reset Password - Candle Store</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
	<div class="container py-5" style="max-width:520px;">
		<h3 class="mb-3">Reset Password</h3>
		<?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
		<?php if ($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?> <a href="login.php">Login</a></div><?php endif; ?>
		<?php if (!$success): ?>
			<?php if ($token === '' || !$valid): ?>
				<div class="alert alert-warning">Invalid or expired reset link.</div>
			<?php else: ?>
				<form method="POST">
					<input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
					<div class="mb-3">
						<label class="form-label">New Password</label>
						<input type="password" class="form-control" name="new_password" required>
					</div>
					<div class="mb-3">
						<label class="form-label">Confirm New Password</label>
						<input type="password" class="form-control" name="confirm_password" required>
					</div>
					<button class="btn btn-primary">Update Password</button>
					<a class="btn btn-link" href="login.php">Back to login</a>
				</form>
			<?php endif; ?>
		<?php endif; ?>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
