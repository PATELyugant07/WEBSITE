<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// If already logged in, redirect appropriately
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
	header('Location: ../admin/dashboard.php');
	exit;
}
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
	header('Location: ../user/dashboard.php');
	exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$identifier = trim($_POST['identifier']); // username or email
	$password = $_POST['password'];

	if (empty($identifier) || empty($password)) {
		$error = 'Please enter your username/email and password.';
	} else {
		// 1) Try admin_users (by username or email)
		$stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = ? OR email = ?");
		$stmt->execute([$identifier, $identifier]);
		$admin = $stmt->fetch();
		if ($admin && password_verify($password, $admin['password'])) {
			$_SESSION['admin_logged_in'] = true;
			$_SESSION['admin_username'] = $admin['username'];
			header('Location: ../admin/dashboard.php');
			exit;
		}

		// 2) Try regular users
		$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
		$stmt->execute([$identifier, $identifier]);
		$user = $stmt->fetch();
		if ($user && password_verify($password, $user['password'])) {
			$_SESSION['user_logged_in'] = true;
			$_SESSION['user_id'] = $user['id'];
			$_SESSION['user_username'] = $user['username'];
			$_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
			$_SESSION['user_email'] = $user['email'];
			header('Location: ../user/dashboard.php');
			exit;
		}

		$error = 'Invalid credentials. Please try again.';
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login - Candle Store</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
	<link href="../assets/css/style.css" rel="stylesheet">
	<style>
	.login-card {
		max-width: 480px;
		margin: 2rem auto;
		box-shadow: 0 0 20px rgba(0,0,0,.1);
		border-radius: 15px;
	}
	.login-header {
		background: linear-gradient(135deg,#667eea 0%,#764ba2 100%);
		color: #fff;
		border-radius: 15px 15px 0 0;
	}
	body {
    background-image: url('../assets/img/bgimage.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
}

</style>

</head>
<body>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-6 col-lg-5">
				<div class="card login-card">
					<div class="card-header login-header text-center py-4">
						<h3 class="mb-0"><i class="fas fa-user"></i> Login</h3>
						<p class="mb-0">Admin and Customers</p>
					</div>
					<div class="card-body p-4">
						<?php if (!empty($error)): ?>
							<div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
						<?php endif; ?>
						<form method="POST">
							<div class="mb-3">
								<label for="identifier" class="form-label">Username or Email</label>
								<input type="text" class="form-control" id="identifier" name="identifier" required>
							</div>
							<div class="mb-4">
								<label for="password" class="form-label">Password</label>
								<input type="password" class="form-control" id="password" name="password" required>
							</div>
							<div class="d-grid">
								<button type="submit" class="btn btn-primary btn-lg">Login</button>
							</div>
						</form>
						<hr class="my-4">
						<div class="d-flex justify-content-between">
							<a href="register.php" class="text-decoration-none">Create an account</a>
							<a href="forgot_password.php" class="text-decoration-none">Forgot password?</a>
						</div>
						<div class="text-center mt-3">
							<a href="../index.php" class="text-decoration-none"><i class="fas fa-arrow-left"></i> Back to Store</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
