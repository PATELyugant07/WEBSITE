<?php
session_start();
require_once '../config/database.php';

$info = '';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($new_password) < 6) {
        $error = 'New password must be at least 6 characters long.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'New password and confirm password do not match.';
    } else {
        try {
            // Try to find in users table first
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
            $stmt->execute([$email]);
            $row = $stmt->fetch();
            $hash = password_hash($new_password, PASSWORD_DEFAULT);

            if ($row) {
                $upd = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
                $upd->execute([$hash, (int)$row['id']]);
                $success = 'Password updated successfully. You can now login.';
            } else {
                // Try admin table
                $stmt = $pdo->prepare('SELECT id FROM admin_users WHERE email = ?');
                $stmt->execute([$email]);
                $admin = $stmt->fetch();
                if ($admin) {
                    $upd = $pdo->prepare('UPDATE admin_users SET password = ? WHERE id = ?');
                    $upd->execute([$hash, (int)$admin['id']]);
                    $success = 'Password updated successfully. You can now login.';
                } else {
                    $error = 'No account found with this email.';
                }
            }
        } catch (Exception $e) {
            $error = 'An error occurred. Please try again later.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Candle Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container py-5" style="max-width:520px;">
        <h3 class="mb-3">Reset Password</h3>
        <p class="text-muted">Enter your account email and set a new password.</p>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?> <a href="login.php">Login</a></div><?php endif; ?>
        <?php if (!$success): ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
                <label class="form-label">New Password</label>
                <input type="password" class="form-control" name="new_password" required>
                <small class="text-muted">Minimum 6 characters</small>
            </div>
            <div class="mb-3">
                <label class="form-label">Confirm New Password</label>
                <input type="password" class="form-control" name="confirm_password" required>
            </div>
            <button class="btn btn-primary">Update Password</button>
            <a href="login.php" class="btn btn-link">Back to login</a>
        </form>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
