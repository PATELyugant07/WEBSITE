# 🕯️ Candle Store - PHP & MySQL E-commerce Website

A complete mini e-commerce website for selling scented candles with full CRUD operations, shopping cart functionality, and admin panel.

## ✨ Features

### 🛒 User Features
- **User Registration & Login**: Create accounts and manage profiles
- **Product Browsing**: View all available candles with beautiful product cards
- **Search & Filter**: Search by name, description, or category with real-time filtering
- **Shopping Cart**: Add, remove, and update quantities with session-based storage
- **Real-time Bill Summary**: Modal popup showing cart contents and total
- **Wishlist Management**: Add/remove products to wishlist with heart icons
- **Order History**: View past orders and track order status with detailed order information
- **User Dashboard**: Comprehensive dashboard with order statistics and recent activity
- **Profile Management**: Edit personal information, contact details, and address
- **Address Management**: Add multiple shipping addresses with default address setting
- **Account Settings**: Change password, manage preferences, and account deletion
- **Mobile Responsive**: Fully responsive design using Bootstrap 5
- **Category Filtering**: Filter products by different candle categories
- **Indian Rupees Currency**: All prices displayed in ₹ (Indian Rupees)

### 👨‍💼 Admin Features
- **Secure Login**: Admin authentication system
- **Dashboard**: Overview with statistics and recent products
- **Product Management**: Full CRUD operations (Create, Read, Update, Delete)
- **Image Upload**: Upload and manage product images
- **Category Management**: Organize products by categories
- **Bulk Operations**: Export, print, and bulk actions

## 🚀 How to Run This Application

### Step 1: Prerequisites
Make sure you have the following installed on your system:
- **XAMPP** (includes Apache, MySQL, and PHP)
- **PHP 7.4 or higher**
- **MySQL 5.7 or higher**

### Step 2: Download and Install XAMPP
1. Go to [https://www.apachefriends.org/](https://www.apachefriends.org/)
2. Download XAMPP for Windows
3. Install XAMPP in the default location (`C:\xampp\`)

### Step 3: Start XAMPP Services
1. Open XAMPP Control Panel
2. Start **Apache** and **MySQL** services
3. Both services should show green status

### Step 4: Set Up the Project
1. **Navigate to htdocs folder**: `C:\xampp\htdocs\`
2. **Create project folder**: Create a folder named `Candle-Store`
3. **Copy project files**: Place all the project files in `C:\xampp\htdocs\Candle-Store\`

### Step 5: Create the Database
1. **Open phpMyAdmin**: Go to `http://localhost/phpmyadmin` in your browser
2. **Import database**: 
   - Click on "Import" tab
   - Choose file: Select `database_setup.sql` from your project folder
   - Click "Go" to import
3. **Verify database**: You should see a new database called `candle_store` with tables `products` and `admin_users`

### Step 6: Configure Database Connection (if needed)
1. Open `config/database.php`
2. Verify these settings match your XAMPP configuration:
   ```php
   $host = 'localhost';
   $dbname = 'candle_store';
   $username = 'root';
   $password = '';
   ```

### Step 7: Create Uploads Directory
1. In your project folder (`C:\xampp\htdocs\Candle-Store\`), create a folder named `uploads`
2. This folder will store product images

### Step 8: Access the Application
1. **Frontend (Customer View)**: 
   - Open your browser
   - Go to: `http://localhost/Candle-Store/`
   - You should see the candle store homepage with products

2. **Admin Panel**:
   - Go to: `http://localhost/Candle-Store/admin/`
   - Login credentials:
     - **Username**: `admin`
     - **Password**: `password`

3. **User Panel**:
   - Go to: `http://localhost/Candle-Store/user/`
   - Register a new account or use demo accounts:
     - **Username**: `john_doe` | Password: `password`
     - **Username**: `jane_smith` | Password: `password`
     - **Username**: `demo_user` | Password: `password`

### Step 9: Test the Features
1. **Browse Products**: View the sample candles on the homepage (prices in ₹)
2. **User Registration**: Create a new account or login with demo accounts
3. **Add to Cart**: Click "Add to Cart" on any product
4. **View Cart**: Click the cart icon in the navigation
5. **Search Products**: Use the search bar to find specific candles
6. **Wishlist**: Click the heart icon to add products to wishlist (requires login)
7. **User Dashboard**: Access your profile, orders, and settings
8. **Profile Management**: Edit personal information and contact details
9. **Order History**: View detailed order information and status
10. **Address Management**: Add multiple shipping addresses
11. **Account Settings**: Change password and manage account preferences
12. **Admin Panel**: Login and try adding/editing products

### Troubleshooting Common Issues

**Issue**: "Connection failed" error
- **Solution**: Make sure MySQL service is running in XAMPP Control Panel

**Issue**: "Page not found" error
- **Solution**: Verify the project is in `C:\xampp\htdocs\Candle-Store\`

**Issue**: Images not displaying
- **Solution**: Check that the `uploads` folder exists and has write permissions

**Issue**: Database import fails
- **Solution**: Make sure MySQL service is running before importing

**Issue**: Admin login doesn't work
- **Solution**: Verify the database was imported correctly and contains the admin user

### File Structure After Setup
```
C:\xampp\htdocs\Candle-Store\
├── index.php                 # Main store page
├── cart.php                  # Shopping cart page
├── admin/                    # Admin panel
│   ├── login.php
│   ├── dashboard.php
│   ├── products.php
│   ├── add_product.php
│   ├── edit_product.php
│   ├── delete_product.php
│   └── logout.php
├── user/                     # User panel
│   ├── login.php
│   ├── register.php
│   ├── dashboard.php
│   ├── profile.php
│   ├── orders.php
│   ├── wishlist.php
│   ├── addresses.php
│   ├── settings.php
│   └── logout.php
├── config/
│   └── database.php          # Database connection
├── includes/
│   └── functions.php         # Helper functions
├── ajax/
│   ├── cart_actions.php      # Cart AJAX endpoints
│   └── wishlist_actions.php  # Wishlist AJAX endpoints
├── assets/
│   ├── css/
│   │   └── style.css         # Custom styles
│   └── js/
│       └── main.js           # JavaScript functions
├── uploads/                  # Product images (create this)
├── database_setup.sql        # Database structure
└── README.md                 # This file
```

## 🚀 Quick Start

### Prerequisites
- XAMPP (Apache + MySQL + PHP)
- PHP 7.4 or higher
- MySQL 5.7 or higher

### Installation

1. **Clone/Download the project**
   ```bash
   # Place the project in your XAMPP htdocs folder
   C:\xampp\htdocs\Candle-Store\
   ```

2. **Start XAMPP**
   - Start Apache and MySQL services
   - Open XAMPP Control Panel

3. **Create Database**
   - Open phpMyAdmin: `http://localhost/phpmyadmin`
   - Import the `database_setup.sql` file
   - Or run the SQL commands manually

4. **Configure Database Connection**
   - Edit `config/database.php`
   - Update database credentials if needed:
   ```php
   $host = 'localhost';
   $dbname = 'candle_store';
   $username = 'root';
   $password = '';
   ```

5. **Create Uploads Directory**
   ```bash
   # Create uploads folder for product images
   mkdir uploads
   ```

6. **Access the Website**
   - Frontend: `http://localhost/Candle-Store/`
   - Admin Panel: `http://localhost/Candle-Store/admin/`

### Admin Login
- **Username**: `admin`
- **Password**: `admin123`

## 📁 Project Structure

```
Candle-Store/
├── index.php              # Main store page
├── cart.php               # Shopping cart page
├── config/
│   └── database.php       # Database configuration
├── includes/
│   └── functions.php      # Helper functions
├── admin/
│   ├── login.php          # Admin login
│   ├── dashboard.php      # Admin dashboard
│   ├── products.php       # Product management
│   ├── add_product.php    # Add new product
│   ├── edit_product.php   # Edit product
│   ├── delete_product.php # Delete product
│   └── logout.php         # Admin logout
├── ajax/
│   └── cart_actions.php   # AJAX cart operations
├── assets/
│   ├── css/
│   │   └── style.css      # Custom styles
│   └── js/
│       └── main.js        # JavaScript functionality
├── uploads/               # Product images (create this folder)
├── database_setup.sql     # Database setup script
└── README.md             # This file
```

## 🎨 Customization

### Adding New Products
1. Login to admin panel
2. Go to "Add Product"
3. Fill in product details
4. Upload product image
5. Save

### Modifying Styles
- Edit `assets/css/style.css` for custom styling
- Uses Bootstrap 5 with custom gradients and animations

### Database Schema
```sql
products table:
- id (Primary Key)
- name (Product name)
- description (Product description)
- price (Product price)
- category (Product category)
- image (Image filename)
- created_at (Timestamp)
- updated_at (Timestamp)
```

## 🔧 Features in Detail

### Shopping Cart
- **Session Storage**: Cart data stored in PHP sessions
- **AJAX Operations**: Real-time cart updates without page reload
- **Quantity Management**: Increase/decrease quantities
- **Remove Items**: Remove individual items or clear entire cart
- **Bill Summary**: Real-time calculation of totals

### Search & Filter
- **Text Search**: Search by product name, description, or category
- **Category Filter**: Filter by specific categories
- **Combined Search**: Use both search and category filters together
- **Real-time Results**: Instant search results

### Admin Panel
- **Dashboard**: Overview with statistics
- **Product CRUD**: Full product management
- **Image Management**: Upload, preview, and replace images
- **Category Management**: Organize products by categories
- **Bulk Operations**: Export, print, and bulk actions

### Responsive Design
- **Mobile First**: Optimized for mobile devices
- **Bootstrap 5**: Modern responsive framework
- **Custom CSS**: Beautiful gradients and animations
- **Touch Friendly**: Optimized for touch devices

## 🛡️ Security Features

- **SQL Injection Protection**: Prepared statements
- **XSS Protection**: HTML escaping
- **File Upload Security**: Image validation and sanitization
- **Session Security**: Secure session handling
- **Input Validation**: Server-side validation

## 🚀 Performance Optimizations

- **Database Indexes**: Optimized queries
- **Image Optimization**: Proper image sizing
- **CSS/JS Minification**: Optimized assets
- **Caching**: Session-based caching
- **Lazy Loading**: Efficient resource loading

## 📱 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## 🔄 Future Enhancements

- User registration and login
- Order management system
- Payment gateway integration
- Email notifications
- Product reviews and ratings
- Wishlist functionality
- Advanced search filters
- Inventory management
- Sales analytics
- Multi-language support

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check XAMPP is running
   - Verify database credentials in `config/database.php`
   - Ensure database exists

2. **Image Upload Issues**
   - Check `uploads/` folder exists and is writable
   - Verify file permissions
   - Check file size limits in PHP

3. **Cart Not Working**
   - Ensure sessions are enabled
   - Check JavaScript console for errors
   - Verify AJAX endpoints are accessible

4. **Admin Login Issues**
   - Default credentials: admin/admin123
   - Check session configuration
   - Verify admin files are accessible

### File Permissions
```bash
# Set proper permissions for uploads folder
chmod 755 uploads/
chmod 644 uploads/*
```

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

1. Fork the project
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

For support and questions:
- Create an issue on GitHub
- Check the troubleshooting section
- Review the code comments

---

**Happy Candle Shopping! 🕯️✨**
