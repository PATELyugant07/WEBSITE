<?php
session_start();

// Destroy user session data
unset($_SESSION['user_logged_in']);
unset($_SESSION['user_id']);
unset($_SESSION['user_username']);
unset($_SESSION['user_name']);
unset($_SESSION['user_email']);

// Also destroy full session as a safeguard
session_destroy();

// Redirect to unified login page
header('Location: ../auth/login.php');
exit;
?>
