<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$orders = [];

// Get user's orders with order items
try {
    $stmt = $pdo->prepare("
        SELECT o.*, 
               COUNT(oi.id) as item_count,
               GROUP_CONCAT(CONCAT(p.name, ' (', oi.quantity, ')') SEPARATOR ', ') as items_summary
        FROM orders o
        LEFT JOIN order_items oi ON o.id = oi.order_id
        LEFT JOIN products p ON oi.product_id = p.id
        WHERE o.user_id = ?
        GROUP BY o.id
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $orders = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_message = 'An error occurred while loading your orders.';
}

// Function to get status badge class
function getStatusBadgeClass($status) {
    switch ($status) {
        case 'pending':
            return 'bg-warning';
        case 'confirmed':
            return 'bg-info';
        case 'shipped':
            return 'bg-primary';
        case 'delivered':
            return 'bg-success';
        case 'cancelled':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}

// Function to get status display text
function getStatusDisplayText($status) {
    switch ($status) {
        case 'pending':
            return 'Pending';
        case 'confirmed':
            return 'Confirmed';
        case 'shipped':
            return 'Shipped';
        case 'delivered':
            return 'Delivered';
        case 'cancelled':
            return 'Cancelled';
        default:
            return ucfirst($status);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - Candle Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-fire"></i> Candle Store
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../cart.php">Cart</a>
                    </li>
                </ul>
                <div class="navbar-nav me-3">
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-edit"></i> Profile</a></li>
                            <li><a class="dropdown-item active" href="orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-user"></i> User Menu</h5>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="dashboard.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                        <a href="profile.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-user-edit"></i> My Profile
                        </a>
                        <a href="orders.php" class="list-group-item list-group-item-action active">
                            <i class="fas fa-shopping-bag"></i> My Orders
                        </a>
                        <a href="wishlist.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-heart"></i> Wishlist
                        </a>
                        <a href="addresses.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-map-marker-alt"></i> Addresses
                        </a>
                        <a href="settings.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><i class="fas fa-shopping-bag"></i> My Orders</h4>
                        <a href="../index.php" class="btn btn-primary btn-sm">
                            <i class="fas fa-shopping-cart"></i> Continue Shopping
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($orders)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-shopping-bag fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No Orders Yet</h5>
                                <p class="text-muted">You haven't placed any orders yet. Start shopping to see your order history here.</p>
                                <a href="../index.php" class="btn btn-primary">
                                    <i class="fas fa-shopping-cart"></i> Start Shopping
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="row">
                                <?php foreach ($orders as $order): ?>
                                    <div class="col-12 mb-4">
                                        <div class="card border">
                                            <div class="card-header bg-light">
                                                <div class="row align-items-center">
                                                    <div class="col-md-6">
                                                        <h6 class="mb-0">
                                                            <strong>Order #<?php echo $order['id']; ?></strong>
                                                        </h6>
                                                        <small class="text-muted">
                                                            Placed on <?php echo date('F j, Y \a\t g:i A', strtotime($order['created_at'])); ?>
                                                        </small>
                                                    </div>
                                                    <div class="col-md-3 text-center">
                                                        <span class="badge <?php echo getStatusBadgeClass($order['status']); ?> fs-6">
                                                            <?php echo getStatusDisplayText($order['status']); ?>
                                                        </span>
                                                    </div>
                                                    <div class="col-md-3 text-end">
                                                        <strong class="text-primary">₹<?php echo number_format($order['total_amount'], 2); ?></strong>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <h6 class="mb-2">Order Items:</h6>
                                                        <p class="text-muted mb-2">
                                                            <?php echo htmlspecialchars($order['items_summary'] ?? 'No items found'); ?>
                                                        </p>
                                                        <p class="mb-1">
                                                            <strong>Items:</strong> <?php echo $order['item_count']; ?>
                                                        </p>
                                                        <p class="mb-1">
                                                            <strong>Payment Method:</strong> 
                                                            <span class="text-capitalize"><?php echo htmlspecialchars($order['payment_method']); ?></span>
                                                        </p>
                                                        <p class="mb-0">
                                                            <strong>Shipping Address:</strong><br>
                                                            <small class="text-muted"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></small>
                                                        </p>
                                                    </div>
                                                    <div class="col-md-4 text-end">
                                                        <button class="btn btn-outline-primary btn-sm mb-2" 
                                                                data-bs-toggle="modal" 
                                                                data-bs-target="#orderModal<?php echo $order['id']; ?>">
                                                            <i class="fas fa-eye"></i> View Details
                                                        </button>
                                                        <?php if ($order['status'] === 'pending'): ?>
                                                            <button class="btn btn-outline-danger btn-sm" disabled>
                                                                <i class="fas fa-times"></i> Cancel Order
                                                            </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Order Details Modal -->
                                    <div class="modal fade" id="orderModal<?php echo $order['id']; ?>" tabindex="-1">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Order #<?php echo $order['id']; ?> Details</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <?php
                                                    // Get detailed order items
                                                    $stmt = $pdo->prepare("
                                                        SELECT oi.*, p.name, p.image, p.description
                                                        FROM order_items oi
                                                        JOIN products p ON oi.product_id = p.id
                                                        WHERE oi.order_id = ?
                                                    ");
                                                    $stmt->execute([$order['id']]);
                                                    $order_items = $stmt->fetchAll();
                                                    ?>
                                                    
                                                    <div class="row mb-3">
                                                        <div class="col-md-6">
                                                            <strong>Order Date:</strong><br>
                                                            <?php echo date('F j, Y \a\t g:i A', strtotime($order['created_at'])); ?>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <strong>Status:</strong><br>
                                                            <span class="badge <?php echo getStatusBadgeClass($order['status']); ?>">
                                                                <?php echo getStatusDisplayText($order['status']); ?>
                                                            </span>
                                                        </div>
                                                    </div>

                                                    <div class="row mb-3">
                                                        <div class="col-md-6">
                                                            <strong>Payment Method:</strong><br>
                                                            <span class="text-capitalize"><?php echo htmlspecialchars($order['payment_method']); ?></span>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <strong>Total Amount:</strong><br>
                                                            <span class="text-primary fw-bold">₹<?php echo number_format($order['total_amount'], 2); ?></span>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <strong>Shipping Address:</strong><br>
                                                        <small class="text-muted"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></small>
                                                    </div>

                                                    <h6>Order Items:</h6>
                                                    <div class="table-responsive">
                                                        <table class="table table-sm">
                                                            <thead>
                                                                <tr>
                                                                    <th>Product</th>
                                                                    <th>Price</th>
                                                                    <th>Quantity</th>
                                                                    <th>Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php foreach ($order_items as $item): ?>
                                                                    <tr>
                                                                        <td>
                                                                            <div class="d-flex align-items-center">
                                                                                <img src="../uploads/<?php echo htmlspecialchars($item['image']); ?>" 
                                                                                     alt="<?php echo htmlspecialchars($item['name']); ?>" 
                                                                                     class="me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                                                                <div>
                                                                                    <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                                                                                </div>
                                                                            </div>
                                                                        </td>
                                                                        <td>₹<?php echo number_format($item['price'], 2); ?></td>
                                                                        <td><?php echo $item['quantity']; ?></td>
                                                                        <td>₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                                                    </tr>
                                                                <?php endforeach; ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>
