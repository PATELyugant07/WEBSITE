<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$wishlist_items = [];
$success_message = '';
$error_message = '';

// Handle remove from wishlist
if (isset($_POST['remove_from_wishlist']) && isset($_POST['product_id'])) {
    $product_id = (int)$_POST['product_id'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM wishlist WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
        
        if ($stmt->rowCount() > 0) {
            $success_message = 'Product removed from wishlist successfully!';
        }
    } catch (PDOException $e) {
        $error_message = 'An error occurred while removing the product from wishlist.';
    }
}

// Get user's wishlist items
try {
    $stmt = $pdo->prepare("
        SELECT w.*, p.name, p.description, p.price, p.image, p.category
        FROM wishlist w
        JOIN products p ON w.product_id = p.id
        WHERE w.user_id = ?
        ORDER BY w.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $wishlist_items = $stmt->fetchAll();
} catch (PDOException $e) {
    $error_message = 'An error occurred while loading your wishlist.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wishlist - Candle Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-fire"></i> Candle Store
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../cart.php">Cart</a>
                    </li>
                </ul>
                <div class="navbar-nav me-3">
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-edit"></i> Profile</a></li>
                            <li><a class="dropdown-item" href="orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-user"></i> User Menu</h5>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="dashboard.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                        <a href="profile.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-user-edit"></i> My Profile
                        </a>
                        <a href="orders.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-shopping-bag"></i> My Orders
                        </a>
                        <a href="wishlist.php" class="list-group-item list-group-item-action active">
                            <i class="fas fa-heart"></i> Wishlist
                        </a>
                        <a href="addresses.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-map-marker-alt"></i> Addresses
                        </a>
                        <a href="settings.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><i class="fas fa-heart"></i> My Wishlist</h4>
                        <a href="../index.php" class="btn btn-primary btn-sm">
                            <i class="fas fa-shopping-cart"></i> Continue Shopping
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if ($success_message): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <?php if ($error_message): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <?php if (empty($wishlist_items)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-heart fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Your Wishlist is Empty</h5>
                                <p class="text-muted">You haven't added any products to your wishlist yet. Start browsing to save your favorite candles!</p>
                                <a href="../index.php" class="btn btn-primary">
                                    <i class="fas fa-shopping-cart"></i> Start Shopping
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="row">
                                <?php foreach ($wishlist_items as $item): ?>
                                    <div class="col-md-6 col-lg-4 mb-4">
                                        <div class="card h-100 product-card">
                                            <div class="position-relative">
                                                <img src="../uploads/<?php echo htmlspecialchars($item['image']); ?>" 
                                                     class="card-img-top" alt="<?php echo htmlspecialchars($item['name']); ?>"
                                                     style="height: 200px; object-fit: cover;">
                                                <div class="position-absolute top-0 end-0 p-2">
                                                    <form method="POST" action="" style="display: inline;">
                                                        <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                                        <button type="submit" name="remove_from_wishlist" class="btn btn-danger btn-sm" 
                                                                onclick="return confirm('Remove this item from wishlist?')">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                            <div class="card-body d-flex flex-column">
                                                <h6 class="card-title"><?php echo htmlspecialchars($item['name']); ?></h6>
                                                <p class="card-text text-muted small">
                                                    <?php echo htmlspecialchars(substr($item['description'], 0, 100)) . '...'; ?>
                                                </p>
                                                <div class="mt-auto">
                                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($item['category']); ?></span>
                                                        <span class="h6 text-primary mb-0">₹<?php echo number_format($item['price'], 2); ?></span>
                                                    </div>
                                                    <div class="d-grid gap-2">
                                                        <button class="btn btn-success btn-sm add-to-cart" 
                                                                data-product-id="<?php echo $item['product_id']; ?>"
                                                                data-product-name="<?php echo htmlspecialchars($item['name']); ?>">
                                                            <i class="fas fa-cart-plus"></i> Add to Cart
                                                        </button>
                                                        <a href="../index.php?product=<?php echo $item['product_id']; ?>" 
                                                           class="btn btn-outline-primary btn-sm">
                                                            <i class="fas fa-eye"></i> View Details
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-footer text-muted small">
                                                Added on <?php echo date('M j, Y', strtotime($item['created_at'])); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <div class="text-center mt-4">
                                <p class="text-muted">
                                    <i class="fas fa-info-circle"></i> 
                                    You have <?php echo count($wishlist_items); ?> item<?php echo count($wishlist_items) !== 1 ? 's' : ''; ?> in your wishlist
                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>
