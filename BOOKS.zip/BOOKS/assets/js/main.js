// Main JavaScript file for Candle Store

document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart functionality
    initializeCart();
    
    // Initialize cart modal
    initializeCartModal();
    
    // Initialize add to cart buttons
    initializeAddToCartButtons();
    
    // Initialize wishlist functionality
    initializeWishlist();
});

// Cart functionality
function initializeCart() {
    // Update cart count on page load
    updateCartCount();
}

// Initialize cart modal
function initializeCartModal() {
    const cartModal = document.getElementById('cartModal');
    if (cartModal) {
        cartModal.addEventListener('show.bs.modal', function() {
            loadCartModal();
        });
    }
}

// Initialize add to cart buttons
function initializeAddToCartButtons() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const productId = this.dataset.productId;
            const productName = this.dataset.productName;
            const productPrice = this.dataset.productPrice;
            
            addToCart(productId, productName, productPrice);
        });
    });
}

// Initialize wishlist functionality
function initializeWishlist() {
    const wishlistButtons = document.querySelectorAll('.add-to-wishlist');
    
    wishlistButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const productId = this.dataset.productId;
            const productName = this.dataset.productName;
            
            addToWishlist(productId, productName, this);
        });
    });
}

// Add product to cart via AJAX
function addToCart(productId, productName, productPrice, quantity = 1) {
    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('product_id', productId);
    formData.append('product_name', productName);
    formData.append('product_price', productPrice);
    formData.append('quantity', quantity);
    
    fetch('ajax/cart_actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update cart count
            updateCartCount(data.data.cart_count);
            
            // Show success message
            showToast(data.message, 'success');
            
            // Update cart modal if open
            const cartModal = document.getElementById('cartModal');
            if (cartModal && cartModal.classList.contains('show')) {
                loadCartModal();
            }
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred. Please try again.', 'error');
    });
}

// Update cart quantity
function updateCartQuantity(productId, quantity) {
    const formData = new FormData();
    formData.append('action', 'update');
    formData.append('product_id', productId);
    formData.append('quantity', quantity);
    
    fetch('ajax/cart_actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartCount(data.data.cart_count);
            showToast(data.message, 'success');
            
            // Reload page to update cart display
            setTimeout(() => {
                location.reload();
            }, 1000);
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred. Please try again.', 'error');
    });
}

// Remove product from cart
function removeFromCart(productId) {
    if (!confirm('Are you sure you want to remove this item from your cart?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'remove');
    formData.append('product_id', productId);
    
    fetch('ajax/cart_actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartCount(data.data.cart_count);
            showToast(data.message, 'success');
            
            // Reload page to update cart display
            setTimeout(() => {
                location.reload();
            }, 1000);
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred. Please try again.', 'error');
    });
}

// Clear cart
function clearCart() {
    if (!confirm('Are you sure you want to clear your entire cart?')) {
        return;
    }
    
    const formData = new FormData();
    formData.append('action', 'clear');
    
    fetch('ajax/cart_actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartCount(data.data.cart_count);
            showToast(data.message, 'success');
            
            // Reload page to update cart display
            setTimeout(() => {
                location.reload();
            }, 1000);
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred. Please try again.', 'error');
    });
}

// Load cart modal content
function loadCartModal() {
    const cartModalBody = document.getElementById('cartModalBody');
    if (!cartModalBody) return;
    
    const formData = new FormData();
    formData.append('action', 'get_cart_modal');
    
    fetch('ajax/cart_actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            cartModalBody.innerHTML = data.data.cart_html;
        } else {
            cartModalBody.innerHTML = '<div class="text-center py-3"><p class="text-muted mb-0">Error loading cart</p></div>';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        cartModalBody.innerHTML = '<div class="text-center py-3"><p class="text-muted mb-0">Error loading cart</p></div>';
    });
}

// Update cart count in navbar
function updateCartCount(count = null) {
    const cartBadge = document.querySelector('.navbar .badge');
    if (cartBadge) {
        if (count !== null) {
            cartBadge.textContent = count;
        } else {
            // Get current count from server
            const formData = new FormData();
            formData.append('action', 'get_cart');
            
            fetch('ajax/cart_actions.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    cartBadge.textContent = data.data.cart_count;
                }
            })
            .catch(error => {
                console.error('Error updating cart count:', error);
            });
        }
    }
}

// Show toast notification
function showToast(message, type = 'info') {
    const toast = document.getElementById('successToast');
    const toastMessage = document.getElementById('toastMessage');
    
    if (toast && toastMessage) {
        // Update message
        toastMessage.textContent = message;
        
        // Update toast type
        const toastHeader = toast.querySelector('.toast-header');
        if (toastHeader) {
            toastHeader.className = 'toast-header';
            if (type === 'success') {
                toastHeader.classList.add('bg-success', 'text-white');
            } else if (type === 'error') {
                toastHeader.classList.add('bg-danger', 'text-white');
            } else {
                toastHeader.classList.add('bg-info', 'text-white');
            }
        }
        
        // Show toast
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
    } else {
        // Fallback alert if toast not available
        alert(message);
    }
}

// Search functionality
function initializeSearch() {
    const searchInput = document.querySelector('input[name="search"]');
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                // Auto-submit search form after 500ms delay
                this.closest('form').submit();
            }, 500);
        });
    }
}

// Initialize search if on index page
if (window.location.pathname.includes('index.php')) {
    initializeSearch();
}

// Utility functions
function formatPrice(price) {
    return '₹' + new Intl.NumberFormat('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(price);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Wishlist functionality
function addToWishlist(productId, productName, button) {
    const formData = new FormData();
    formData.append('action', 'add_to_wishlist');
    formData.append('product_id', productId);
    
    fetch('ajax/wishlist_actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update button appearance
            button.classList.remove('btn-outline-danger');
            button.classList.add('btn-danger');
            button.innerHTML = '<i class="fas fa-heart"></i>';
            
            showToast(data.message, 'success');
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred. Please try again.', 'error');
    });
}

function removeFromWishlist(productId, button) {
    const formData = new FormData();
    formData.append('action', 'remove_from_wishlist');
    formData.append('product_id', productId);
    
    fetch('ajax/wishlist_actions.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update button appearance
            button.classList.remove('btn-danger');
            button.classList.add('btn-outline-danger');
            button.innerHTML = '<i class="fas fa-heart"></i>';
            
            showToast(data.message, 'success');
            
            // If on wishlist page, remove the card
            if (window.location.pathname.includes('wishlist.php')) {
                const card = button.closest('.col-md-6, .col-lg-4');
                if (card) {
                    card.remove();
                }
            }
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred. Please try again.', 'error');
    });
}

// Export functions for global use
window.CandleStore = {
    addToCart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    addToWishlist,
    removeFromWishlist,
    showToast,
    formatPrice
};
