<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update':
                if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
                    updateCartQuantity($_POST['product_id'], (int)$_POST['quantity']);
                }
                break;
            case 'remove':
                if (isset($_POST['product_id'])) {
                    removeFromCart($_POST['product_id']);
                }
                break;
            case 'clear':
                clearCart();
                break;
        }
        // Redirect to prevent form resubmission
        header('Location: cart.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Candle Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-fire"></i> Candle Store
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="cart.php">Cart</a>
                    </li>
                </ul>
                
                <!-- Search Form -->
                <form class="d-flex me-3" method="GET" action="index.php">
                    <input class="form-control me-2" type="search" name="search" placeholder="Search candles...">
                    <button class="btn btn-outline-light" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
                
                <!-- Cart Icon -->
                <div class="navbar-nav">
                    <a class="nav-link position-relative" href="#" data-bs-toggle="modal" data-bs-target="#cartModal">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?php echo getCartItemCount(); ?>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h4 class="mb-0">
                            <i class="fas fa-shopping-cart"></i> Shopping Cart
                        </h4>
                    </div>
                    <div class="card-body">
                        <?php if (empty($_SESSION['cart'])): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Your cart is empty</h5>
                                <p class="text-muted">Add some beautiful candles to get started!</p>
                                <a href="index.php" class="btn btn-primary">
                                    <i class="fas fa-shopping-bag"></i> Continue Shopping
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Product</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Subtotal</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($_SESSION['cart'] as $product_id => $item): ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="flex-shrink-0">
                                                            <div class="cart-product-image">
                                                                <i class="fas fa-fire text-primary"></i>
                                                            </div>
                                                        </div>
                                                        <div class="flex-grow-1 ms-3">
                                                            <h6 class="mb-0"><?php echo htmlspecialchars($item['name']); ?></h6>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>₹<?php echo formatPrice($item['price']); ?></td>
                                                <td>
                                                    <form method="POST" class="d-inline">
                                                        <input type="hidden" name="action" value="update">
                                                        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                                                        <div class="input-group input-group-sm" style="width: 120px;">
                                                            <button type="button" class="btn btn-outline-secondary quantity-btn" data-action="decrease">-</button>
                                                            <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" 
                                                                   min="1" max="99" class="form-control text-center quantity-input">
                                                            <button type="button" class="btn btn-outline-secondary quantity-btn" data-action="increase">+</button>
                                                        </div>
                                                    </form>
                                                </td>
                                                <td>₹<?php echo formatPrice($item['price'] * $item['quantity']); ?></td>
                                                <td>
                                                    <form method="POST" class="d-inline">
                                                        <input type="hidden" name="action" value="remove">
                                                        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                                                        <button type="submit" class="btn btn-danger btn-sm" 
                                                                onclick="return confirm('Remove this item from cart?')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="action" value="clear">
                                    <button type="submit" class="btn btn-outline-danger" 
                                            onclick="return confirm('Clear all items from cart?')">
                                        <i class="fas fa-trash"></i> Clear Cart
                                    </button>
                                </form>
                                <a href="index.php" class="btn btn-outline-primary">
                                    <i class="fas fa-arrow-left"></i> Continue Shopping
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Order Summary -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-receipt"></i> Order Summary
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($_SESSION['cart'])): ?>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Subtotal:</span>
                                <span>₹<?php echo formatPrice(getCartTotal()); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Shipping:</span>
                                <span class="text-success">Free</span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between mb-3">
                                <strong>Total:</strong>
                                <strong class="text-primary">₹<?php echo formatPrice(getCartTotal()); ?></strong>
                            </div>
                            
                            <button class="btn btn-success w-100 mb-2" onclick="checkout()">
                                <i class="fas fa-credit-card"></i> Proceed to Checkout
                            </button>
                            
                            <div class="text-center">
                                <small class="text-muted">
                                    <i class="fas fa-lock"></i> Secure checkout powered by Stripe
                                </small>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-3">
                                <p class="text-muted mb-0">No items in cart</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Bill Summary -->
                <div class="card mt-3">
                    <div class="card-header">
                        <h6 class="mb-0">
                            <i class="fas fa-calculator"></i> Bill Summary
                        </h6>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($_SESSION['cart'])): ?>
                            <div class="bill-items">
                                <?php foreach ($_SESSION['cart'] as $product_id => $item): ?>
                                    <div class="d-flex justify-content-between mb-1">
                                        <small><?php echo htmlspecialchars($item['name']); ?> x <?php echo $item['quantity']; ?></small>
                                        <small>₹<?php echo formatPrice($item['price'] * $item['quantity']); ?></small>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <strong>Total:</strong>
                                <strong>₹<?php echo formatPrice(getCartTotal()); ?></strong>
                            </div>
                        <?php else: ?>
                            <p class="text-muted text-center mb-0">Empty cart</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Handle quantity buttons
        document.addEventListener('DOMContentLoaded', function() {
            const quantityBtns = document.querySelectorAll('.quantity-btn');
            
            quantityBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const input = this.parentNode.querySelector('.quantity-input');
                    const action = this.dataset.action;
                    
                    if (action === 'increase') {
                        input.value = parseInt(input.value) + 1;
                    } else if (action === 'decrease') {
                        if (parseInt(input.value) > 1) {
                            input.value = parseInt(input.value) - 1;
                        }
                    }
                    
                    // Auto-submit form when quantity changes
                    input.closest('form').submit();
                });
            });
        });
        
        function checkout() {
            alert('Checkout functionality would be implemented here with Stripe or PayPal integration.');
        }
    </script>
</body>
</html>
