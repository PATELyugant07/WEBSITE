<?php
// Helper functions for the Candle Store

/**
 * Add product to cart
 */
function addToCart($product_id, $product_name, $product_price, $quantity = 1) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['quantity'] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = [
            'name' => $product_name,
            'price' => $product_price,
            'quantity' => $quantity
        ];
    }
}

/**
 * Remove product from cart
 */
function removeFromCart($product_id) {
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
}

/**
 * Update cart item quantity
 */
function updateCartQuantity($product_id, $quantity) {
    if (isset($_SESSION['cart'][$product_id])) {
        if ($quantity <= 0) {
            removeFromCart($product_id);
        } else {
            $_SESSION['cart'][$product_id]['quantity'] = $quantity;
        }
    }
}

/**
 * Get cart total
 */
function getCartTotal() {
    $total = 0;
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $total += $item['price'] * $item['quantity'];
        }
    }
    return $total;
}

/**
 * Get cart item count
 */
function getCartItemCount() {
    $count = 0;
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $count += $item['quantity'];
        }
    }
    return $count;
}

/**
 * Clear cart
 */
function clearCart() {
    $_SESSION['cart'] = [];
}

/**
 * Format price in Indian Rupees
 */
function formatPrice($price) {
    return '₹' . number_format($price, 2);
}

/**
 * Sanitize input
 */
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate image upload
 */
function validateImage($file) {
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    $max_size = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowed_types)) {
        return "Invalid file type. Only JPG, PNG, and GIF are allowed.";
    }
    
    if ($file['size'] > $max_size) {
        return "File size too large. Maximum size is 5MB.";
    }
    
    return true;
}

/**
 * Upload image
 */
function uploadImage($file, $upload_dir = 'uploads/') {
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    $filename = time() . '_' . basename($file['name']);
    $target_path = $upload_dir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return $filename;
    }
    
    return false;
}

/**
 * Delete image
 */
function deleteImage($filename, $upload_dir = 'uploads/') {
    $file_path = $upload_dir . $filename;
    if (file_exists($file_path)) {
        return unlink($file_path);
    }
    return false;
}

/**
 * Get product image src path with placeholder fallback.
 * $prefix is the path prefix relative to the current script (e.g., '../' for admin pages).
 */
function productImageSrc($filename, $prefix = '') {
    $uploadsDir = __DIR__ . '/../uploads/';
    $publicUploads = $prefix . 'uploads/';
    $placeholder = $prefix . 'assets/img/placeholder.svg';

    if (!empty($filename) && file_exists($uploadsDir . $filename)) {
        return $publicUploads . rawurlencode($filename);
    }
    return $placeholder;
}
?>
