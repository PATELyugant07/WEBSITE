<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Set JSON header
header('Content-Type: application/json');

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Get action from POST data
$action = isset($_POST['action']) ? $_POST['action'] : '';

$response = ['success' => false, 'message' => '', 'data' => null];

switch ($action) {
    case 'add':
        if (isset($_POST['product_id']) && isset($_POST['product_name']) && isset($_POST['product_price'])) {
            $product_id = $_POST['product_id'];
            $product_name = $_POST['product_name'];
            $product_price = (float)$_POST['product_price'];
            $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
            
            addToCart($product_id, $product_name, $product_price, $quantity);
            
            $response['success'] = true;
            $response['message'] = 'Product added to cart successfully!';
            $response['data'] = [
                'cart_count' => getCartItemCount(),
                'cart_total' => getCartTotal()
            ];
        } else {
            $response['message'] = 'Missing required product information.';
        }
        break;
        
    case 'update':
        if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
            $product_id = $_POST['product_id'];
            $quantity = (int)$_POST['quantity'];
            
            updateCartQuantity($product_id, $quantity);
            
            $response['success'] = true;
            $response['message'] = 'Cart updated successfully!';
            $response['data'] = [
                'cart_count' => getCartItemCount(),
                'cart_total' => getCartTotal()
            ];
        } else {
            $response['message'] = 'Missing required information.';
        }
        break;
        
    case 'remove':
        if (isset($_POST['product_id'])) {
            $product_id = $_POST['product_id'];
            
            removeFromCart($product_id);
            
            $response['success'] = true;
            $response['message'] = 'Product removed from cart!';
            $response['data'] = [
                'cart_count' => getCartItemCount(),
                'cart_total' => getCartTotal()
            ];
        } else {
            $response['message'] = 'Missing product ID.';
        }
        break;
        
    case 'clear':
        clearCart();
        
        $response['success'] = true;
        $response['message'] = 'Cart cleared successfully!';
        $response['data'] = [
            'cart_count' => 0,
            'cart_total' => 0
        ];
        break;
        
    case 'get_cart':
        $cart_items = [];
        if (isset($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $product_id => $item) {
                $cart_items[] = [
                    'product_id' => $product_id,
                    'name' => $item['name'],
                    'price' => $item['price'],
                    'quantity' => $item['quantity'],
                    'subtotal' => $item['price'] * $item['quantity']
                ];
            }
        }
        
        $response['success'] = true;
        $response['data'] = [
            'cart_items' => $cart_items,
            'cart_count' => getCartItemCount(),
            'cart_total' => getCartTotal()
        ];
        break;
        
    case 'get_cart_modal':
        $cart_html = '';
        $total = 0;
        
        if (empty($_SESSION['cart'])) {
            $cart_html = '<div class="text-center py-3"><p class="text-muted mb-0">Your cart is empty</p></div>';
        } else {
            $cart_html = '<div class="table-responsive"><table class="table table-sm">';
            $cart_html .= '<thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Total</th></tr></thead><tbody>';
            
            foreach ($_SESSION['cart'] as $product_id => $item) {
                $subtotal = $item['price'] * $item['quantity'];
                $total += $subtotal;
                
                $cart_html .= '<tr>';
                $cart_html .= '<td>' . htmlspecialchars($item['name']) . '</td>';
                $cart_html .= '<td>₹' . number_format($item['price'], 2) . '</td>';
                $cart_html .= '<td>' . $item['quantity'] . '</td>';
                $cart_html .= '<td>₹' . number_format($subtotal, 2) . '</td>';
                $cart_html .= '</tr>';
            }
            
            $cart_html .= '</tbody></table></div>';
            $cart_html .= '<hr><div class="d-flex justify-content-between"><strong>Total:</strong><strong>₹' . number_format($total, 2) . '</strong></div>';
        }
        
        $response['success'] = true;
        $response['data'] = [
            'cart_html' => $cart_html,
            'cart_count' => getCartItemCount(),
            'cart_total' => getCartTotal()
        ];
        break;
        
    default:
        $response['message'] = 'Invalid action.';
        break;
}

// Return JSON response
echo json_encode($response);
?>
