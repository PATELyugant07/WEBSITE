<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Get the item ID to delete
$id = (int)$_GET['id']; // Cast to integer to prevent SQL injection

// Delete related records in the orders table
$sqlDeleteOrders = "DELETE FROM orders WHERE item_id = $id";
$conn->query($sqlDeleteOrders);

// Delete the item from the items table
$sqlDeleteItem = "DELETE FROM items WHERE id = $id";
if ($conn->query($sqlDeleteItem) === TRUE) {
    header('Location: inventory.php'); // Redirect back to inventory page
    exit();
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
