<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['item_id'])) {
    $item_id = intval($_GET['item_id']);
    $sql = "SELECT * FROM items WHERE id = $item_id";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $item = $result->fetch_assoc();
    } else {
        die("Item not found.");
    }
} else {
    die("Invalid request.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Form</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="max-w-md w-full bg-white p-8 rounded-lg shadow-md">
        <h2 class="text-2xl font-semibold mb-4">Purchase Item: <?php echo htmlspecialchars($item['name']); ?></h2>
        <div class="mb-4">
            <img src="uploads/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="w-full h-auto mb-4 rounded-lg">
            <p class="text-lg font-bold">Price: $<?php echo htmlspecialchars($item['price']); ?></p>
        </div>
        <form action="process_purchase.php" method="POST">
            <input type="hidden" name="item_id" value="<?php echo htmlspecialchars($item['id']); ?>">
            <input type="hidden" name="item_name" value="<?php echo htmlspecialchars($item['name']); ?>">
            <input type="hidden" name="item_price" value="<?php echo htmlspecialchars($item['price']); ?>">
            <input type="hidden" name="item_image" value="<?php echo htmlspecialchars($item['image']); ?>">
            <div class="mb-4">
                <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($_SESSION['username']); ?>" readonly class="mt-1 px-3 py-2 border border-gray-300 rounded-md w-full bg-gray-100">
            </div>
            <div class="mb-4">
                <label for="location" class="block text-sm font-medium text-gray-700">Location</label>
                <input type="text" id="location" name="location" placeholder="Your location" required class="mt-1 px-3 py-2 border border-gray-300 rounded-md w-full">
            </div>
            <div class="mb-4">
                <label for="purchase_method" class="block text-sm font-medium text-gray-700">Purchase Method</label>
                <select id="purchase_method" name="purchase_method" required class="mt-1 px-3 py-2 border border-gray-300 rounded-md w-full">
                    <option value="" disabled selected>Select a method</option>
                    <option value="credit_card">Credit Card</option>
                    <option value="paypal">PayPal</option>
                    <option value="bank_transfer">Bank Transfer</option>
                </select>
            </div>
            <button type="submit" class="w-full bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-105 hover:bg-gray-700">Complete Purchase</button>
        </form>
    </div>
</body>
</html>
<?php $conn->close(); ?>
