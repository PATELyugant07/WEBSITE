<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT item_id, item_name, item_price, item_image, username, location, purchase_method, purchase_date FROM purchases WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $_SESSION['username']);
$stmt->execute();
$result = $stmt->get_result();

$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
unset($_SESSION['message']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase History</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .sidebar {
            width: 250px;
            min-height: 100vh; /* Ensures the sidebar covers the full height */
        }
    </style>
</head>
<body class="bg-gray-100 flex h-screen">
    <!-- Sidebar -->
    <aside class="bg-gray-800 text-white sidebar flex-shrink-0 p-4 fixed h-full">
        <div class="text-center mb-8">
            <a href="Home.php">
                <img src="img/Air-Jordan-Logo-1.png" alt="Logo" class="h-12 mx-auto">
            </a>
        </div>
        <ul class="space-y-2">
            <li>
                <a href="displayorder.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Order</span>
                </a>
            </li>
            <li>
                <a href="profile.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-user mr-3"></i>
                    <span>Profile</span>
                </a>
            </li>
            <li>
                <a href="#" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-cog mr-3"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li>
                <a href="Home.php?action=logout" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-sign-out-alt mr-3"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </aside>
    
    <!-- Main Content -->
    <main class="ml-64 flex-1 p-6"> <!-- Adjusted margin-left to match sidebar width -->
        <header class="mb-6">
            <h1 class="text-2xl font-bold">Purchase History for <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
        </header>

        <!-- Display message -->
        <?php if ($message): ?>
            <div class="max-w-screen-lg mx-auto p-6 mb-4 bg-green-100 text-green-800 border border-green-300 rounded-md">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <section>
            <div class="max-w-screen-lg mx-auto p-6">
                <h1 class="text-2xl font-bold mb-4">Purchase History</h1>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <div class="bg-white p-4 rounded-lg shadow-md">
                            <img src="uploads/<?php echo htmlspecialchars($row['item_image']); ?>" alt="<?php echo htmlspecialchars($row['item_name']); ?>" class="w-full h-48 object-cover rounded-t-lg">
                            <div class="mt-4">
                                <h2 class="text-xl font-semibold"><?php echo htmlspecialchars($row['item_name']); ?></h2>
                                <p class="text-gray-600">Price: $<?php echo number_format($row['item_price'], 2); ?></p>
                                <p class="text-gray-600">Location: <?php echo htmlspecialchars($row['location']); ?></p>
                                <p class="text-gray-600">Purchase Method: <?php echo htmlspecialchars($row['purchase_method']); ?></p>
                                <p class="text-gray-600">Date: <?php echo date('F j, Y, g:i a', strtotime($row['purchase_date'])); ?></p>
                                <form action="delete_order.php" method="POST" class="mt-4">
                                    <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($row['item_id']); ?>">
                                    <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Delete Order</button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </section>
    </main>
</body>
</html>
<?php $stmt->close(); $conn->close(); ?>
