<?php
session_start();

// Function to handle logout
function handleLogout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Check if the user has requested to log out
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    handleLogout();
}

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Custom Styles */
        .sidebar {
            width: 250px;
        }
    </style>
</head>
<body class="bg-gray-100 flex h-screen">
    <!-- Sidebar -->
    <!-- Sidebar -->
    <aside class="bg-gray-800 text-white sidebar flex-shrink-0 p-4">
        <div class="text-center mb-8">
            <a href="Home.php">
                <img src="img/Air-Jordan-Logo-1.png" alt="Logo" class="h-12 mx-auto">
            </a>
        </div>
        <ul class="space-y-2">
        <li>
                <a href="admin_dashboard.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-tachometer-alt mr-3"></i>
                    <span>Dashboard</span>
                </a>
            </li>
                <li>
                    <a href="additem.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-plus-circle mr-3"></i>
                        <span>Add item</span>
                    </a>
                </li>
                <li>
                    <a href="inventory.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-warehouse mr-3"></i>
                        <span>Stock</span>
                    </a>
                </li>
                <li>
                    <a href="admin_settings.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-cog mr-3"></i>
                        <span>Settings</span>
                    </a>
                </li>
                <li>
                    <a href="?action=logout" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-sign-out-alt mr-3"></i>
                        <span>Logout</span>
                    </a>
                </li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-6">
        <header class="mb-6">
            <h1 class="text-2xl font-bold">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        </header>

        <section>
            <!-- Add your dashboard content here -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-semibold mb-4">Recent Activity</h2>
                    <p>Your recent activities will appear here.</p>
                </div>
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-semibold mb-4">Messages</h2>
                    <p>Check your messages and notifications.</p>
                </div>
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-xl font-semibold mb-4">Account Overview</h2>
                    <p>View and manage your account settings.</p>
                </div>
            </div>
        </section>
    </main>
</body>
</html>
