<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_id = intval($_POST['item_id']);
    $item_name = $conn->real_escape_string($_POST['item_name']);
    $item_price = floatval($_POST['item_price']);
    $item_image = $conn->real_escape_string($_POST['item_image']);
    $username = $conn->real_escape_string($_SESSION['username']); // Get username from session
    $location = $conn->real_escape_string($_POST['location']);
    $purchase_method = $conn->real_escape_string($_POST['purchase_method']);
    $purchase_date = date('Y-m-d H:i:s');

    $sql = "INSERT INTO purchases (item_id, item_name, item_price, item_image, username, location, purchase_method, purchase_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('isisssss', $item_id, $item_name, $item_price, $item_image, $username, $location, $purchase_method, $purchase_date);

    if ($stmt->execute()) {
        // Store purchase details in session
        $_SESSION['purchase'] = [
            'item_id' => $item_id,
            'item_name' => $item_name,
            'item_price' => $item_price,
            'item_image' => $item_image,
            'username' => $username,
            'location' => $location,
            'purchase_method' => $purchase_method,
            'purchase_date' => $purchase_date
        ];
        header("Location: purchase_success.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Invalid request.";
}
$conn->close();
?>

