<?php
session_start();

$servername = "localhost";
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "website"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$item_name = isset($_POST['item_name']) ? trim($_POST['item_name']) : '';
$item_price = isset($_POST['item_price']) ? floatval($_POST['item_price']) : 0;
$item_description = isset($_POST['item_description']) ? trim($_POST['item_description']) : '';
$item_category = isset($_POST['item_category']) ? trim($_POST['item_category']) : '';
$item_quantity = isset($_POST['item_quantity']) ? intval($_POST['item_quantity']) : 0;

// Handle file upload
$item_image = '';
if (isset($_FILES['item_image']) && $_FILES['item_image']['error'] === UPLOAD_ERR_OK) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["item_image"]["name"]);
    if (move_uploaded_file($_FILES["item_image"]["tmp_name"], $target_file)) {
        $item_image = basename($_FILES["item_image"]["name"]);
    } else {
        die("Error uploading file.");
    }
}

// Insert item into the database
$sql = "INSERT INTO items (name, price, description, category, quantity, image) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("sdssis", $item_name, $item_price, $item_description, $item_category, $item_quantity, $item_image);
if ($stmt->execute()) {
    // Redirect back to add item page with success message
    header("Location: additem.php?message=Item added successfully");
    exit();
} else {
    die("Execute failed: " . $stmt->error);
}

$stmt->close();
$conn->close();
?>
