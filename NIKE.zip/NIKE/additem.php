<?php
session_start();

// Function to handle logout
function handleLogout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Check if the user has requested to log out
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    handleLogout();
}

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Check for success message
$message = isset($_GET['message']) ? $_GET['message'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Custom Styles */
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 1.5rem;
            flex-grow: 1;
            background-color: #f9fafb;
        }

    </style>
</head>
<body class="flex h-screen">
    <!-- Sidebar -->
    <aside class="bg-gray-800 text-white sidebar flex-shrink-0 p-4">
        <div class="text-center mb-8">
            <a href="Home.php">
                <img src="img/Air-Jordan-Logo-1.png" alt="Logo" class="h-12 mx-auto">
            </a>
        </div>
        <ul class="space-y-2">
            <li>
                <a href="admin_dashboard.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-tachometer-alt mr-3"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="additem.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-plus-circle mr-3"></i>
                    <span>Add item</span>
                </a>
            </li>
            <li>
                <a href="inventory.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-warehouse mr-3"></i>
                    <span>Stock</span>
                </a>
            </li>
            <li>
                <a href="admin_settings.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-cog mr-3"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li>
                <a href="?action=logout" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-sign-out-alt mr-3"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </aside>

    <!-- Main Content -->
    <div class="main-content">
        <?php if ($message): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <section class="bg-white p-8 rounded-lg shadow-md mt-6 max-w-2xl mx-auto">
            <h2 class="text-2xl font-semibold mb-6">Add New Item</h2>
            <form action="add_item.php" method="POST" enctype="multipart/form-data">
                <div class="grid gap-6 mb-6 md:grid-cols-2">
                    <div>
                        <label for="item_name" class="block text-sm font-medium text-gray-700 mb-2">Item Name</label>
                        <input type="text" id="item_name" name="item_name" required
                            class="block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div>
                        <label for="item_price" class="block text-sm font-medium text-gray-700 mb-2">Item Price</label>
                        <input type="number" id="item_price" name="item_price" required
                            class="block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>

                <div class="mb-6">
                    <label for="item_description" class="block text-sm font-medium text-gray-700 mb-2">Item Description</label>
                    <textarea id="item_description" name="item_description" rows="4" required
                        class="block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                </div>

                <div class="mb-6">
                    <label for="item_category" class="block text-sm font-medium text-gray-700 mb-2">Category</label>
                    <select id="item_category" name="item_category" required
                        class="block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="" disabled selected>Select a category</option>
                        <option value="sneakers">Sneakers</option>
                        <option value="running">Running</option>
                        <option value="casual">Casual</option>
                        <!-- Add more categories as needed -->
                    </select>
                </div>

                <div class="grid gap-6 mb-6 md:grid-cols-2">
                    <div>
                        <label for="item_quantity" class="block text-sm font-medium text-gray-700 mb-2">Quantity in Stock</label>
                        <input type="number" id="item_quantity" name="item_quantity" required
                            class="block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <div>
                        <label for="item_image" class="block text-sm font-medium text-gray-700 mb-2">Item Image</label>
                        <input type="file" id="item_image" name="item_image" accept="image/*"
                            class="block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>

                <button type="submit"
                    class="w-full py-3 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    Add Item
                </button>
            </form>
        </section>
    </div>
</body>
</html>
