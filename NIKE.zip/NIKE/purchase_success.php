<?php
session_start();
if (!isset($_SESSION['username']) || !isset($_SESSION['purchase'])) {
    header("Location: login.php");
    exit();
}

// Retrieve purchase details from the session
$purchase = $_SESSION['purchase'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Bill</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="max-w-2xl mx-auto my-10 bg-white p-8 rounded-lg shadow-lg">
        <h1 class="text-2xl font-bold mb-4">Purchase Bill</h1>
        <hr class="mb-6">
        <div class="mb-4">
            <h2 class="text-xl font-semibold">Item Details</h2>
            <p><strong>Item Name:</strong> <?php echo htmlspecialchars($purchase['item_name']); ?></p>
            <p><strong>Item Price:</strong> $<?php echo number_format($purchase['item_price'], 2); ?></p>
            <p><strong>Purchase Date:</strong> <?php echo htmlspecialchars($purchase['purchase_date']); ?></p>
        </div>
        <div class="mb-4">
            <h2 class="text-xl font-semibold">User Details</h2>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($purchase['username']); ?></p>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($purchase['location']); ?></p>
        </div>
        <div class="mb-4">
            <h2 class="text-xl font-semibold">Payment Method</h2>
            <p><strong>Method:</strong> <?php echo htmlspecialchars($purchase['purchase_method']); ?></p>
        </div>
        <div class="flex justify-center space-x-4">
            <!-- Print Bill Button -->
            <button onclick="window.print()" class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600">
                Print Bill
            </button>
            
            <!-- Exit Button -->
            <a href="men.php" class="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600">
                Exit
            </a>
        </div>
    </div>
</body>
</html>
