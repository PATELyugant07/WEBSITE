    <?php
    session_start();

    // Function to handle redirection based on user role
    function redirectToAppropriatePage() {
        if (isset($_SESSION['username'])) {
            $username = $_SESSION['username'];
            
            if ($username === 'admin') {
                header("Location: adminpage.php");
                exit();
            } else {
                header("Location: userpage.php");
                exit();
            }
        }
    }

    // Handle redirection if "Dashboard" button is clicked
    if (isset($_GET['redirect']) && $_GET['redirect'] === 'dashboard') {
        redirectToAppropriatePage();
    }

    // Handle logout functionality
    if (isset($_GET['action']) && $_GET['action'] === 'logout') {
        session_unset();
        session_destroy();
        header("Location: Home.php");
        exit();
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>NIKE</title>
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <style>
            .ticker-wrapper {
                overflow: hidden;
                position: relative;
                height: 2rem; /* Adjust height as needed */
            }
            
            .ticker-content {
                display: flex;
                white-space: nowrap;
                animation: scroll-left 30s linear infinite;
                position: absolute;
                width: 80%;
            }
            
            .ticker-item {
                padding: 0 2rem; /* Adjust spacing as needed */
            }

            @keyframes scroll-left {
                0% {
                    transform: translateX(100%);
                }
                100% {
                    transform: translateX(-100%);
                }
            }
            .scroll-container {
                display: flex;
                overflow-x: auto;
                scroll-behavior: smooth;
                padding: 1rem 0;
            }

            .scroll-container::-webkit-scrollbar {
                height: 8px;
            }

            .scroll-container::-webkit-scrollbar-thumb {
                background: rgba(0, 0, 0, 0.2);
                border-radius: 4px;
            }

            .scroll-container::-webkit-scrollbar-thumb:hover {
                background: rgba(0, 0, 0, 0.4);
            }

            .scroll-item {
                flex: 0 0 auto;
                width: 300px;
                margin-right: 1rem;
                border-radius: 0.5rem;
                overflow: hidden;
                background: #ffffff;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                transition: transform 0.3s;
            }

            .scroll-item img {
                width: 100%;
                height: 200px;
                object-fit: cover;
                border-bottom: 2px solid #ddd;
            }

            .scroll-item .text-content {
                padding: 1rem;
                text-align: center;
            }

            .scroll-item .text-content h3 {
                font-size: 1.25rem;
                font-weight: 600;
            }

            .scroll-item .text-content p {
                margin-top: 0.5rem;
                font-size: 1rem;
                color: #666;
            }

            .scroll-item .prize-label {
                display: block;
                margin-top: 1rem;
                padding: 0.5rem;
                background-color: #ffcc00;
                color: #333;
                font-weight: bold;
                border-radius: 0.375rem;
            }
            
        </style>
    </head>
    <body class="bg-gray-80 flex flex-col min-h-screen">

        <!-- Secondary Navigation Bar -->
        <nav class="bg-gray-200 text-gray-800">
            <div class="max-w-screen-xl mx-auto flex justify-between items-center ">
                <!-- Logo -->
                <a href="Home.php">
                    <img src="img/Air-Jordan-Logo-1.png" alt="Logo" class="h-10 w-auto">
                </a>
                <!-- Navigation Links -->
                <ul class="hidden md:flex space-x-6">
                    <li><a href="#" class="hover:text-gray-600">Find a Store</a></li>
                    <li><a href="help.php" class="hover:text-gray-600">Help</a></li>
                    <li><a href="join.php" class="hover:text-gray-600">Join Us</a></li>
                </ul>
                <div class="flex space-x-6 items-center">
                    <form action="search.php" method="get" class="flex items-center">
                        <input type="text" name="query" placeholder="Search..." class="px-2 py-1 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-gray-400">
                        <button type="submit" class="bg-gray-800 text-white px-3 py-1 rounded-r-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-400">
                            <i class="fas fa-search text-xl"></i>
                        </button>
                    </form>
                    <a href="cart.php" class="text-gray-800 hover:text-gray-600">
                        <i class="fas fa-shopping-cart text-xl"></i>
                    </a>
                    <a href="about.php" class="hover:text-gray-600">About</a>
                    <a href="contact.php" class="hover:text-gray-600">Contact</a>
                </div>
            </div>
        </nav>

    <!-- Main Navigation Bar -->
    <header class="bg-white shadow-md">
        <nav class="flex items-center p-2 max-w-screen-xl mx-auto">
            <!-- Logo -->
            <a href="Home.php" class="flex-shrink-0">
                <img src="img/th.jpeg" alt="NIKE Logo" class="h-10 w-auto">
            </a>
            
            <!-- Navigation Links -->
            <ul class="hidden md:flex flex-grow justify-center space-x-6 mx-6">
                <li><a href="Home.php" class="text-gray-800 hover:text-gray-600">New & Featured</a></li>
                <li><a href="men.php" class="text-gray-800 hover:text-gray-600">Products</a></li>
                <li><a href="snkr.php" class="text-gray-800 hover:text-gray-600">SNKR</a></li>
            </ul>
            
            <!-- Authentication Buttons -->
            <div class="flex-shrink-0 space-x-4">
                <?php if (isset($_SESSION['username'])): ?>
                    <a href="?redirect=dashboard"><button class="bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-110 hover:bg-gray-700">Dashboard</button></a>
                    <a href="?action=logout"><button class="bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-110 hover:bg-gray-700">Logout</button></a>
                <?php else: ?>
                    <a href="./signup.php"><button class="bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-110 hover:bg-gray-700">Sign Up</button></a>
                    <a href="./login.php"><button class="bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-110 hover:bg-gray-700">Login</button></a>
                <?php endif; ?>
            </div>
        </nav>
    </header>

        <main class="flex-1">

            <!-- News Ticker -->
            <section class="bg-gray-300 text-black py-2">
                <div class="ticker-wrapper">
                    <div class="ticker-content">
                        <span class="ticker-item">Exclusive Offer: Save 25% on your next purchase! Limited time only!</span>
                        <span class="ticker-item">New Arrivals: Discover the latest trends in our new spring collection!</span>
                        <span class="ticker-item">Update: We’re launching a new eco-friendly product line. Stay tuned for more details!</span>
                        <span class="ticker-item">Limited Time Offer: Get a free gift with every purchase over $80!</span>
                        <span class="ticker-item">Hot New Styles: Update your wardrobe with our fresh, cutting-edge designs for this season.</span>
                        <span class="ticker-item">News Flash: Our athletes are gearing up for the upcoming championship. Follow their journey with us!</span>
                    </div>
                </div>
            </section>

            
        </main>
        <!-- Image and Text Section -->
        <section class="relative bg-gray-800 text-white">
                <img src="img\y.jpg" alt="Promotional Image" class="w-full h-96 object-cover">
                <div class="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black to-transparent py-4 text-center">
                    <h2 class="text-2xl font-bold">Discover the Best of Nike</h2>
                    <p class="text-lg mt-2">Explore our latest collections and elevate your game with the best gear available.</p>
                </div>
            </section>
            <main class="flex-1">

    <!-- Featured Sections -->
    <section class="py-12 bg-gray-80">
        <div class="max-w-screen-xl mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-8">Featured Collections</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                
                <!-- Featured Item 1 -->
                <div class="relative bg-gray-200 rounded-lg shadow-lg overflow-hidden">
                    <img src="img/ki.jpg" alt="Featured Collection 1" class="w-full h-100 object-cover">
                    <div class="p-4">
                        <h3 class="text-xl font-semibold">Innovative Footwear</h3>
                        <p class="mt-2">Step into the future with our cutting-edge designs.</p>
                        <a href="#" class="inline-block mt-4 px-4 py-2 bg-gray-800 text-white rounded hover:bg-gray-700">Explore</a>
                    </div>
                </div>
                
                <!-- Featured Item 2 -->
                <div class="relative bg-gray-200 rounded-lg shadow-lg overflow-hidden">
                    <img src="img/jj.jpg" alt="Featured Collection 2" class="w-full h-100 object-cover">
                    <div class="p-4">
                        <h3 class="text-xl font-semibold">Sustainable Styles</h3>
                        <p class="mt-2">Eco-friendly apparel that makes a statement.</p>
                        <a href="#" class="inline-block mt-4 px-4 py-2 bg-gray-800 text-white rounded hover:bg-gray-700">Explore</a>
                    </div>
                </div>
                
                <!-- Featured Item 3 -->
                <div class="relative bg-gray-200 rounded-lg shadow-lg overflow-hidden">
                    <img src="img\mike-von-FipmLJsL_xE-unsplash.jpg" alt="Featured Collection 3" class="w-full h-100 object-cover">
                    <div class="p-4">
                        <h3 class="text-xl font-semibold">Performance Gear</h3>
                        <p class="mt-2">Elevate your game with our high-performance gear.</p>
                        <a href="#" class="inline-block mt-4 px-4 py-2 bg-gray-800 text-white rounded hover:bg-gray-700">Explore</a>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!-- Main Content -->
    <main class="flex-1">

    <!-- Trending Section with Horizontal Scroll -->
    <section class="py-12 bg-gray-100">
        <div class="max-w-screen-xl mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-8">Trending Shoe</h2>
            <div class="flex overflow-x-auto space-x-4 pb-4">
                
                <!-- Trending Item 1 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f1.png" alt="Trending Item 1" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h3 class="text-xl font-semibold text-gray-800">Luka 3 PF 'Motorsport'</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹11 895.0</p>
                    </div>
                </div>
                
                <!-- Trending Item 2 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f2.png" alt="Trending Item 2" class="w-full h-48 object-cover">
                    <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">Gaiannis 6 EP</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹11 999.0</p>
                    </div>
                </div>

                <!-- Trending Item 3 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f3.png" alt="Trending Item 3" class="w-full h-48 object-cover">
                    <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">Gaiannis 6 [TEAM BANK] EP</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹12 999.0</p>
                    </div>
                </div>
                
                <!-- Trending Item 4 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f4.png" alt="Trending Item 4" class="w-full h-48 object-cover">
                    <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">Gaiannis 6 EP</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹12 978.0</p>
                    </div>
                </div>

                <!-- Trending Item 5 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f5.png" alt="Trending Item 5" class="w-full h-48 object-cover">
                    <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">Sabrina 2 EP</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹10 657.0</p>
                    </div>
                </div>

                <!-- Trending Item 6 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f6.png" alt="Trending Item 6" class="w-full h-48 object-cover">
                    <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">Tatum 2 PF</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹9 999.0</p>
                    </div>
                </div>

                <!-- Trending Item 7 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f7.png" alt="Trending Item 7" class="w-full h-48 object-cover">
                    <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">Luka 3 PF 'Blurred Vision</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹13 889.0</p>
                    </div>
                </div>

                <!-- Trending Item 8 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f8.png" alt="Trending Item 8" class="w-full h-48 object-cover">
                    <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">Luka 2 PF</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹12 669.0</p>
                    </div>
                </div>

                <!-- Trending Item 9 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f9.png" alt="Trending Item 9" class="w-full h-48 object-cover">
                    <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">Air Jordan Legecy 312 Low</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹12 999.0</p>
                    </div>
                </div>

                <!-- Trending Item 10 -->
                <div class="flex-none bg-white rounded-lg shadow-lg overflow-hidden w-64 transform transition-transform duration-300 hover:scale-105 hover:shadow-xl">
                    <img src="img\f10.png" alt="Trending Item 10" class="w-full h-48 object-cover">
                    <div class="p-4">
                    <h3 class="text-xl font-semibold text-gray-800">Jordan One Take 5 Quai 54 PF</h3>
                        <p class="mt-2 text-gray-600">Basketball shoes</p>
                        <p class="mt-2 text-black">MRP:₹10 999.0</p>
                    </div>
                </div>

            </div>
        </div>
    </section>
    </main>
    <section class="py-12 bg-white">
        <div class="max-w-screen-xl mx-auto px-4">
            <h2 class="text-3xl font-bold text-center text-gray-900 mb-8">Members Benefits</h2>
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

                <!-- Benefit 1 -->
                <div class="bg-gray-100 p-6 rounded-lg shadow-md flex flex-col items-center">
                    <div class="mb-4">
                        <svg class="w-16 h-16 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10V3l-7 7 7 7V13h5v-3h-5z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2">Exclusive Discounts</h3>
                    <p class="text-gray-700 text-center">Enjoy up to 30% off on all products, including new arrivals and top sellers.</p>
                </div>

                <!-- Benefit 2 -->
                <div class="bg-gray-100 p-6 rounded-lg shadow-md flex flex-col items-center">
                    <div class="mb-4">
                        <svg class="w-16 h-16 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 9l6 6 6-6"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2">Early Access</h3>
                    <p class="text-gray-700 text-center">Get exclusive early access to sales and new collections before anyone else.</p>
                </div>

                <!-- Benefit 3 -->
                <div class="bg-gray-100 p-6 rounded-lg shadow-md flex flex-col items-center">
                    <div class="mb-4">
                        <svg class="w-16 h-16 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16a4 4 0 11-8 0 4 4 0 018 0zM17 12V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6M7 10h10"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2">Free Shipping</h3>
                    <p class="text-gray-700 text-center">Enjoy free standard shipping on all orders with no minimum purchase required.</p>
                </div>

                <!-- Benefit 4 -->
                <div class="bg-gray-100 p-6 rounded-lg shadow-md flex flex-col items-center">
                    <div class="mb-4">
                        <svg class="w-16 h-16 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8V4m0 16v-4m8-8l-4 4m0 0l-4-4m4 4V3"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2">Exclusive Events</h3>
                    <p class="text-gray-700 text-center">Receive invitations to exclusive events, including product launches and VIP parties.</p>
                </div>

                <!-- Benefit 5 -->
                <div class="bg-gray-100 p-6 rounded-lg shadow-md flex flex-col items-center">
                    <div class="mb-4">
                        <svg class="w-16 h-16 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4.5l3 1.5M12 4v4M4 6a2 2 0 00-2 2v12a2 2 0 002 2h16a2 2 0 002-2V8a2 2 0 00-2-2H4z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2">Personalized Support</h3>
                    <p class="text-gray-700 text-center">Get personalized support from our team to assist with all your needs and queries.</p>
                </div>

                <!-- Benefit 6 -->
                <div class="bg-gray-100 p-6 rounded-lg shadow-md flex flex-col items-center">
                    <div class="mb-4">
                        <svg class="w-16 h-16 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2">Loyalty Rewards</h3>
                    <p class="text-gray-700 text-center">Earn points with every purchase and redeem them for rewards and discounts.</p>
                </div>

            </div>
        </div>
    </section>


    <!-- Additional Content (existing code here) -->
    </main>
            <!-- Additional Content -->
            <?php if (isset($_SESSION['username'])): ?>
                <!-- User-specific content -->
            <?php endif; ?>
        </main>

        <footer class="bg-gray-100 text-black py-4 border-t border-gray-300">
        <div class="max-w-screen-xl mx-auto">
            <!-- Footer Top Section -->
            <div class="flex justify-between items-center mb-4">
                <ul class="flex space-x-4">
                <li><a href="Home.php" class="text-gray-800 hover:text-gray-600">New & Featured</a></li>
                <li><a href="men.php" class="text-gray-800 hover:text-gray-600">Products</a></li>
                </ul>
                <div class="flex space-x-4">
                    <a href="https://www.instagram.com" target="_blank" class="hover:text-gray-600"><i class="fab fa-instagram text-xl"></i></a>
                    <a href="https://play.google.com" target="_blank" class="hover:text-gray-600"><i class="fab fa-google-play text-xl"></i></a>
                    <a href="https://www.facebook.com" target="_blank" class="hover:text-gray-600"><i class="fab fa-facebook-f text-xl"></i></a>
                </div>
            </div>

            <!-- Footer Bottom Section -->
            <p class="text-center text-sm">&copy; 2024 NIKE. All Rights Reserved.</p>
        </div>
    </footer>


    </body>
    </html>
