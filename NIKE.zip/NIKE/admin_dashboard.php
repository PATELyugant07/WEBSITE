<?php
session_start();

// Function to handle redirection based on user role
function redirectToAppropriatePage() {
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];
        
        if ($username === 'admin') {
            header("Location: admin_dashboard.php");
            exit();
        } else {
            header("Location: user_dashboard.php");
            exit();
        }
    }
}

// Handle redirection if "Dashboard" button is clicked
if (isset($_GET['redirect']) && $_GET['redirect'] === 'dashboard') {
    redirectToAppropriatePage();
}

// Handle logout functionality
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header("Location: Home.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 1.5rem;
            flex-grow: 1;
            background-color: #f9fafb;
        }

        .card {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            transition: box-shadow 0.3s ease;
        }
        .card:hover {
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.15);
        }

        .chart-container {
            position: relative;
            height: 400px;
        }

        .recent-activities {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
        }
    </style>
</head>
<body class="flex h-screen">
    <!-- Sidebar -->
    <aside class="bg-gray-800 text-white sidebar flex-shrink-0 p-4">
        <div class="text-center mb-8">
            <a href="Home.php">
                <img src="img/Air-Jordan-Logo-1.png" alt="Logo" class="h-12 mx-auto">
            </a>
        </div>
        <ul class="space-y-2">
        <li>
                <a href="admin_dashboard.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-tachometer-alt mr-3"></i>
                    <span>Dashboard</span>
                </a>
            </li>
                <li>
                    <a href="additem.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-plus-circle mr-3"></i>
                        <span>Add item</span>
                    </a>
                </li>
                <li>
                    <a href="inventory.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-warehouse mr-3"></i>
                        <span>Stock</span>
                    </a>
                </li>
                <li>
                    <a href="admin_settings.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-cog mr-3"></i>
                        <span>Settings</span>
                    </a>
                </li>
                <li>
                    <a href="?action=logout" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-sign-out-alt mr-3"></i>
                        <span>Logout</span>
                    </a>
                </li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="main-content p-6">
        <header class="mb-6">
            <h1 class="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        </header>

        <!-- Summary Cards -->
        <div class="flex flex-wrap -mx-4 mb-8">
            <div class="w-full md:w-1/3 px-4 mb-4">
                <div class="card">
                    <h2 class="text-lg font-semibold mb-2">Total Users</h2>
                    <p class="text-3xl font-bold text-gray-700">1,234</p>
                </div>
            </div>
            <div class="w-full md:w-1/3 px-4 mb-4">
                <div class="card">
                    <h2 class="text-lg font-semibold mb-2">Total Orders</h2>
                    <p class="text-3xl font-bold text-gray-700">567</p>
                </div>
            </div>
            <div class="w-full md:w-1/3 px-4 mb-4">
                <div class="card">
                    <h2 class="text-lg font-semibold mb-2">Total Sales</h2>
                    <p class="text-3xl font-bold text-gray-700">$12,345</p>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="flex flex-wrap -mx-4 mb-8">
            <div class="w-full lg:w-1/2 px-4 mb-4 chart-container">
                <div class="card">
                    <h2 class="text-lg font-semibold mb-4">Sales Trend</h2>
                    <canvas id="salesTrendChart"></canvas>
                </div>
            </div>
            <div class="w-full lg:w-1/2 px-4 mb-4 chart-container">
                <div class="card">
                    <h2 class="text-lg font-semibold mb-4">User Growth</h2>
                    <canvas id="userGrowthChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Recent Activities -->
        <div class="recent-activities mt-8">
            <h2 class="text-lg font-semibold mb-4">Recent Activities</h2>
            <ul class="list-disc list-inside text-gray-700">
                <li class="mb-2">User John Doe updated his profile.</li>
                <li class="mb-2">Order #12345 was shipped.</li>
                <li class="mb-2">New product added: Super Widget.</li>
            </ul>
        </div>
    </main>

    <script>
        // Example chart for Sales Trend
        const ctxSalesTrend = document.getElementById('salesTrendChart').getContext('2d');
        new Chart(ctxSalesTrend, {
            type: 'line',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June'],
                datasets: [{
                    label: 'Sales',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Example chart for User Growth
        const ctxUserGrowth = document.getElementById('userGrowthChart').getContext('2d');
        new Chart(ctxUserGrowth, {
            type: 'bar',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June'],
                datasets: [{
                    label: 'New Users',
                    data: [10, 20, 15, 25, 30, 45],
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
