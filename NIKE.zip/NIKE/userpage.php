<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle logout functionality
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header("Location: Home.php");
    exit();
}

// Determine which section to display
$view = isset($_GET['view']) ? $_GET['view'] : 'dashboard';
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';

// Fetch orders for the orders view
$orders = [];
if ($view === 'orders') {
    $sql = "SELECT o.id, o.item_id, o.quantity, o.location, o.payment_method, o.order_date, i.name, i.image
            FROM orders o
            JOIN items i ON o.item_id = i.id
            WHERE o.username = ?"; // Assuming orders are linked to a specific user
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param('s', $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        die("Error executing query: " . $stmt->error);
    } else if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
    }
    $stmt->close();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($view === 'orders' ? 'Orders' : 'Dashboard'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .sidebar {
            width: 250px;
        }
    </style>
    <script>
        // Function to show message
        function showMessage(message) {
            alert(message);
        }

        // Check if there's a message to show
        window.onload = function() {
            <?php if ($message): ?>
                showMessage("<?php echo $message; ?>");
            <?php endif; ?>
        };
    </script>
</head>
<body class="bg-gray-100 flex h-screen">
    <!-- Sidebar -->
    <aside class="bg-gray-800 text-white sidebar flex-shrink-0 p-4">
        <div class="text-center mb-8">
            <a href="Home.php">
                <img src="img/Air-Jordan-Logo-1.png" alt="Logo" class="h-12 mx-auto">
            </a>
        </div>
        <ul class="space-y-2">
            <li>
                <a href="displayorder.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Order</span>
                </a>
            </li>
            <li>
                <a href="profile.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-user mr-3"></i>
                    <span>Profile</span>
                </a>
            </li>
            <li>
                <a href="#" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-cog mr-3"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li>
                <a href="?action=logout" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-sign-out-alt mr-3"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </aside>
    
    <!-- Main Content -->
    <main class="flex-1 p-6">
        <header class="mb-6">
            <h1 class="text-2xl font-bold">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        </header>

        <?php if ($view === 'dashboard'): ?>
            <section>
                <!-- Dashboard content -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div class="bg-white p-6 rounded-lg shadow-md">
                        <h2 class="text-xl font-semibold mb-4">Recent Activity</h2>
                        <p>Your recent activities will appear here.</p>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow-md">
                        <h2 class="text-xl font-semibold mb-4">Messages</h2>
                        <p>Check your messages and notifications.</p>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow-md">
                        <h2 class="text-xl font-semibold mb-4">Account Overview</h2>
                        <p>View and manage your account settings.</p>
                    </div>
                </div>
            </section>
        <?php elseif ($view === 'orders'): ?>
            <section>
                <div class="max-w-screen-lg mx-auto p-6">
                    <h1 class="text-2xl font-bold mb-4">Orders</h1>
                    <div class="flex flex-wrap -mx-4">
                        <?php if (!empty($orders)): ?>
                            <?php foreach ($orders as $order): ?>
                                <div class="w-full sm:w-1/2 lg:w-1/3 xl:w-1/4 p-4">
                                    <div class="bg-white p-6 rounded-lg shadow-lg">
                                        <img src="uploads/<?php echo htmlspecialchars($order['image']); ?>" alt="<?php echo htmlspecialchars($order['name']); ?>" class="w-full h-32 object-cover rounded-t-lg mb-4">
                                        <h2 class="text-xl font-semibold mb-2"><?php echo htmlspecialchars($order['name']); ?></h2>
                                        <p class="text-gray-700 mb-2">Quantity: <?php echo htmlspecialchars($order['quantity']); ?></p>
                                        <p class="text-gray-700 mb-2">Location: <?php echo htmlspecialchars($order['location']); ?></p>
                                        <p class="text-gray-700 mb-2">Payment Method: <?php echo htmlspecialchars($order['payment_method']); ?></p>
                                        <p class="text-gray-700 mb-2">Order Date: <?php echo htmlspecialchars($order['order_date']); ?></p>
                                        <div class="flex justify-between mt-4">
                                            <a href="delete_order.php?id=<?php echo htmlspecialchars($order['id']); ?>" class="text-red-500 hover:underline" onclick="return confirm('Are you sure you want to cancel this order?');">Cancel Order</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-center text-gray-700">No orders found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    </main>
</body>
</html>

<?php
$conn->close();
?>
