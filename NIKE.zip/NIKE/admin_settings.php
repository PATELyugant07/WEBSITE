<?php
session_start();

// Ensure only admins can access this page
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header("Location: Home.php");
    exit();
}

// Handle logout functionality
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header("Location: Home.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .sidebar {
            width: 250px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
        }

        .main-content {
            margin-left: 250px;
            padding: 1.5rem;
            flex-grow: 1;
            background-color: #f9fafb;
        }

        .card {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            transition: box-shadow 0.3s ease;
        }
        .card:hover {
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.15);
        }
    </style>
</head>
<body class="flex h-screen">
    <!-- Sidebar -->
    <aside class="bg-gray-800 text-white sidebar flex-shrink-0 p-4">
        <div class="text-center mb-8">
            <a href="Home.php">
                <img src="img/Air-Jordan-Logo-1.png" alt="Logo" class="h-12 mx-auto">
            </a>
        </div>
        <ul class="space-y-2">
        <li>
                <a href="admin_dashboard.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-tachometer-alt mr-3"></i>
                    <span>Dashboard</span>
                </a>
            </li>
                <li>
                    <a href="additem.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-plus-circle mr-3"></i>
                        <span>Add item</span>
                    </a>
                </li>
                <li>
                    <a href="inventory.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-warehouse mr-3"></i>
                        <span>Stock</span>
                    </a>
                </li>
                <li>
                    <a href="admin_settings.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-cog mr-3"></i>
                        <span>Settings</span>
                    </a>
                </li>
                <li>
                    <a href="?action=logout" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-sign-out-alt mr-3"></i>
                        <span>Logout</span>
                    </a>
                </li>
      
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="main-content p-6">
        <header class="mb-6">
            <h1 class="text-3xl font-bold text-gray-900">Admin Settings</h1>
        </header>

        <!-- General Settings -->
        <div class="mb-8">
            <div class="card">
                <h2 class="text-xl font-semibold mb-4">General Settings</h2>
                <form>
                    <div class="mb-4">
                        <label for="site-name" class="block text-gray-700 font-medium mb-2">Site Name</label>
                        <input type="text" id="site-name" name="site-name" class="form-input w-full border-gray-300 rounded-lg" placeholder="Enter site name">
                    </div>
                    <div class="mb-4">
                        <label for="site-email" class="block text-gray-700 font-medium mb-2">Site Email</label>
                        <input type="email" id="site-email" name="site-email" class="form-input w-full border-gray-300 rounded-lg" placeholder="Enter site email">
                    </div>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">Save Settings</button>
                </form>
            </div>
        </div>

        <!-- User Management -->
        <div class="mb-8">
            <div class="card">
                <h2 class="text-xl font-semibold mb-4">User Management</h2>
                <form>
                    <div class="mb-4">
                        <label for="user-role" class="block text-gray-700 font-medium mb-2">Default User Role</label>
                        <select id="user-role" name="user-role" class="form-select w-full border-gray-300 rounded-lg">
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">Update Role</button>
                </form>
            </div>
        </div>

        <!-- System Preferences -->
        <div>
            <div class="card">
                <h2 class="text-xl font-semibold mb-4">System Preferences</h2>
                <form>
                    <div class="mb-4">
                        <label for="site-language" class="block text-gray-700 font-medium mb-2">Site Language</label>
                        <select id="site-language" name="site-language" class="form-select w-full border-gray-300 rounded-lg">
                            <option value="en">English</option>
                            <option value="es">Spanish</option>
                            <option value="fr">French</option>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label for="timezone" class="block text-gray-700 font-medium mb-2">Timezone</label>
                        <select id="timezone" name="timezone" class="form-select w-full border-gray-300 rounded-lg">
                            <option value="UTC">UTC</option>
                            <option value="America/New_York">America/New York</option>
                            <option value="Europe/London">Europe/London</option>
                        </select>
                    </div>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">Update Preferences</button>
                </form>
            </div>
        </div>
    </main>
</body>
</html>
