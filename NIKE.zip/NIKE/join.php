<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Us - Unlock Exclusive Benefits</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
    <style>
   .hero-bg {
        background-image: url('img/j1.jpg'); /* Updated to new image */
        background-size: cover;
        background-position: center;
        background-blend-mode: overlay;
    }
    </style>
</head>
<body class="bg-gray-100">

    <!-- Hero Section -->
    <section class="hero-bg h-screen flex items-center justify-center text-center text-white">
        <div>
            <h1 class="text-5xl font-bold mb-4">Join Our Community</h1>
            <p class="text-2xl mb-8">Become a part of something bigger. Unlock exclusive benefits, resources, and connections.</p>
        </div>
    </section>

   <!-- Benefits Section -->
<section class="py-24 px-4 bg-white">
    <div class="container mx-auto">
        <h2 class="text-4xl font-bold text-center mb-12">Why Join Us?</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-12">
            <!-- Benefit 1 -->
            <div class="text-center">
                <i class="fas fa-book-reader text-5xl text-purple-600 mb-6"></i>
                <h3 class="text-2xl font-semibold mb-4">Premium Content</h3>
                <p class="text-gray-600">Gain access to exclusive articles, tutorials, and resources crafted by industry experts.</p>
            </div>
            <!-- Benefit 2 -->
            <div class="text-center">
                <i class="fas fa-users text-5xl text-green-500 mb-6"></i>
                <h3 class="text-2xl font-semibold mb-4">Networking Opportunities</h3>
                <p class="text-gray-600">Connect with like-minded professionals and expand your network globally.</p>
            </div>
            <!-- Benefit 3 -->
            <div class="text-center">
                <i class="fas fa-tags text-5xl text-yellow-500 mb-6"></i>
                <h3 class="text-2xl font-semibold mb-4">Exclusive Discounts</h3>
                <p class="text-gray-600">Enjoy member-only discounts on events, products, and services.</p>
            </div>
            <!-- Benefit 4 -->
            <div class="text-center">
                <i class="fas fa-briefcase text-5xl text-blue-500 mb-6"></i>
                <h3 class="text-2xl font-semibold mb-4">Career Development</h3>
                <p class="text-gray-600">Access career advancement tools, job listings, and mentorship programs.</p>
            </div>
            <!-- Benefit 5 -->
            <div class="text-center">
                <i class="fas fa-graduation-cap text-5xl text-red-500 mb-6"></i>
                <h3 class="text-2xl font-semibold mb-4">Personalized Learning</h3>
                <p class="text-gray-600">Receive personalized learning paths tailored to your career goals and interests.</p>
            </div>
            <!-- Benefit 6 -->
            <div class="text-center">
                <i class="fas fa-headset text-5xl text-indigo-500 mb-6"></i>
                <h3 class="text-2xl font-semibold mb-4">24/7 Support</h3>
                <p class="text-gray-600">Get 24/7 support from our community and experts whenever you need help.</p>
            </div>
        </div>
    </div>
</section>

<!-- Include Font Awesome for Icons -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <!-- Features Section -->
    <section class="py-24 bg-gray-100">
        <div class="container mx-auto">
            <h2 class="text-4xl font-bold text-center mb-12">Membership Features</h2>
            <div class="flex flex-wrap justify-center">
                <!-- Feature 1 -->
                <div class="w-full md:w-1/2 lg:w-1/3 p-4">
                    <div class="bg-white p-8 rounded-lg shadow-lg h-full">
                        <h3 class="text-2xl font-semibold mb-4">Interactive Webinars</h3>
                        <p class="text-gray-600">Participate in live webinars hosted by industry leaders.</p>
                    </div>
                </div>
                <!-- Feature 2 -->
                <div class="w-full md:w-1/2 lg:w-1/3 p-4">
                    <div class="bg-white p-8 rounded-lg shadow-lg h-full">
                        <h3 class="text-2xl font-semibold mb-4">Resource Library</h3>
                        <p class="text-gray-600">Get unlimited access to a comprehensive library of resources.</p>
                    </div>
                </div>
                <!-- Feature 3 -->
                <div class="w-full md:w-1/2 lg:w-1/3 p-4">
                    <div class="bg-white p-8 rounded-lg shadow-lg h-full">
                        <h3 class="text-2xl font-semibold mb-4">Certification Programs</h3>
                        <p class="text-gray-600">Enroll in certification programs to boost your credentials.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action Section -->
    <section class="py-24 bg-blue-600 text-white text-center">
        <div class="container mx-auto">
            <h2 class="text-4xl font-bold mb-4">Ready to Elevate Your Career?</h2>
            <p class="text-xl mb-8">Join us today and start accessing exclusive benefits and resources designed to help you grow.</p>
            <a href="signup.php" class="bg-white text-blue-600 px-8 py-3 rounded-full text-lg hover:bg-gray-200">Join Now</a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-6 bg-gray-800 text-white text-center">
        <p>&copy; 2024 Your Company. All rights reserved.</p>
    </footer>

</body>
</html>
