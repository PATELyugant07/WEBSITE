-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2025 at 02:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `added_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`, `description`, `category`, `image`, `quantity`) VALUES
(9, 'air max 07', 800000.00, 'got it', 'Clothing', 'f9.png', 788),
(14, 'my', 500.00, 'asasas', 'Clothing', 'f5.png', 548),
(18, 'air dunks pro', 900.00, 'asasc', 'sneakers', 'f2.png', 855),
(21, 'nike air force 3', 500.00, 'adad', 'Electronics', 'f4.png', 50),
(22, 'air dunks', 600.00, 'aaaxaxa', 'running', 'f3.png', 1022),
(23, 'air forces', 700.00, 'got the brand', 'sneaker', 'air.png', 50),
(24, 'air dunks black', 500.00, 'aanxjasncsa', 'running', 'WIDE.png', 0),
(25, 'nike air force 6', 400.00, 'ssds', 'sneakers', 'f2.png', 111);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` decimal(10,2) NOT NULL,
  `item_image` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `purchase_method` varchar(50) NOT NULL,
  `purchase_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `item_id`, `item_name`, `item_price`, `item_image`, `username`, `location`, `purchase_method`, `purchase_date`) VALUES
(3, 18, 'air dunks pro', 900.00, 'f2.png', 'hu', 'dcdvc', 'paypal', '2024-09-08 07:39:49'),
(22, 9, 'air max 07', 800000.00, 'f9.png', 'hu', 'buhari', 'credit_card', '2024-09-10 06:26:55'),
(23, 25, 'nike air force 6', 400.00, 'f2.png', 'yugant', 'buhari', 'credit_card', '2024-09-10 06:32:20'),
(25, 9, 'air max 07', 800000.00, 'f9.png', 'yugant', 'buhari', 'bank_transfer', '2024-10-08 07:26:33'),
(26, 9, 'air max 07', 800000.00, 'f9.png', 'patel', 'dcsdsv', 'paypal', '2025-02-06 06:01:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'admin', 'yugantp7270@gmail.com', '$2y$10$IeoSKEVodDfW6dGMw5X.Len12nH9M8NEKMNfXLx/w3Cs3ZFOtsSWe', '2024-08-31 06:58:35'),
(2, 'yugant', '22bca177@vtcbcsr.edu.in', '$2y$10$en3stQRAbOpNUW1BViu9G.bIUC33Xj4tQjN1rkxrG44HzSUKL43aW', '2024-08-31 06:59:20'),
(3, 'pratham', 'pratham@gmail.com', '$2y$10$f7YGj6Db.O8FY9UYQbVmvORAQAAP643WjuBBJMV4y4DVB1QGtKL6.', '2024-09-03 06:57:18'),
(4, 'hu', 'hu@gmail.com', '$2y$10$hFKVRGEFJWSEO3Iz8hvc5uT7vsaXJRyOqpUAHVz61.EUXsU2k243.', '2024-09-04 09:34:25'),
(5, 'patel', 'pATEL@gmail.com', '$2y$10$PmWCYJxvn54eGkWReSWYIu93RZ9AZ1dofu0FXBNnft5xDdANjbBRW', '2025-02-06 05:00:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
