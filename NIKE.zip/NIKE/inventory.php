<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "website"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to handle logout
function handleLogout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Check if the user has requested to log out
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    handleLogout();
}

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Fetch items
$sql = "SELECT id, name, price, description, category, quantity, image FROM items";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Custom Styles */
        .sidebar {
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            overflow-y: auto; /* Allow scrolling within the sidebar if needed */
            height: 100vh; /* Full viewport height */
        }

        .main-content {
            margin-left: 250px; /* Same width as the sidebar */
            padding: 1.5rem; /* Adjust padding as needed */
            overflow-y: auto; /* Allow scrolling in main content area */
            height: 100vh; /* Full viewport height */
        }

        .container {
            display: flex;
        }

        .content {
            flex: 1;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container">
        <!-- Sidebar -->
        <aside class="bg-gray-800 text-white sidebar flex-shrink-0 p-4">
            <div class="text-center mb-8">
                <a href="Home.php">
                    <img src="img/Air-Jordan-Logo-1.png" alt="Logo" class="h-12 mx-auto">
                </a>
            </div>
            <ul class="space-y-2">
                <li>
                    <a href="admin_dashboard.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-tachometer-alt mr-3"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="additem.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-plus-circle mr-3"></i>
                        <span>Add item</span>
                    </a>
                </li>
                <li>
                    <a href="inventory.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-warehouse mr-3"></i>
                        <span>Stock</span>
                    </a>
                </li>
                <li>
                    <a href="admin_settings.php" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-cog mr-3"></i>
                        <span>Settings</span>
                    </a>
                </li>
                <li>
                    <a href="?action=logout" class="flex items-center p-2 rounded-lg hover:bg-gray-700">
                        <i class="fas fa-sign-out-alt mr-3"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <div class="max-w-screen-lg mx-auto p-6 bg-white rounded-lg shadow-md mt-8">
                <h1 class="text-2xl font-bold mb-4">Items List</h1>
                <?php if ($result->num_rows > 0): ?>
                    <table class="w-full border-collapse">
                        <thead>
                            <tr>
                                <th class="border px-4 py-2">ID</th>
                                <th class="border px-4 py-2">Name</th>
                                <th class="border px-4 py-2">Price</th>
                                <th class="border px-4 py-2">Description</th>
                                <th class="border px-4 py-2">Category</th>
                                <th class="border px-4 py-2">Quantity</th>
                                <th class="border px-4 py-2">Image</th>
                                <th class="border px-4 py-2">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td class="border px-4 py-2"><?php echo htmlspecialchars($row['id']); ?></td>
                                    <td class="border px-4 py-2"><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td class="border px-4 py-2">$<?php echo htmlspecialchars($row['price']); ?></td>
                                    <td class="border px-4 py-2"><?php echo htmlspecialchars($row['description']); ?></td>
                                    <td class="border px-4 py-2"><?php echo htmlspecialchars($row['category']); ?></td>
                                    <td class="border px-4 py-2"><?php echo htmlspecialchars($row['quantity']); ?></td>
                                    <td class="border px-4 py-2">
                                        <?php if (!empty($row['image'])): ?>
                                            <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" class="w-24 h-24 object-cover">
                                        <?php endif; ?>
                                    </td>
                                    <td class="border px-4 py-2">
                                        <!-- Edit and Delete Icons -->
                                        <a href="edititem.php?id=<?php echo $row['id']; ?>" class="text-blue-500 hover:text-blue-700 mr-2">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="deleteitem.php?id=<?php echo $row['id']; ?>" class="text-red-500 hover:text-red-700" onclick="return confirm('Are you sure you want to delete this item?');">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No items found.</p>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>

<?php
$conn->close();
?>
