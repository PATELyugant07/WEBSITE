<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Fetch the item details to edit
$id = (int)$_GET['id']; // Cast to integer to prevent SQL injection
$sql = "SELECT * FROM items WHERE id = $id";
$result = $conn->query($sql);
$item = $result->fetch_assoc();

// Update the item details in the database
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $price = (float)$conn->real_escape_string($_POST['price']); // Ensure price is a float
    $description = $conn->real_escape_string($_POST['description']);
    $category = $conn->real_escape_string($_POST['category']);
    $quantity = (int)$conn->real_escape_string($_POST['quantity']); // Ensure quantity is an integer

    // Image upload handling
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $target = "uploads/" . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    } else {
        $image = $item['image']; // Keep the old image if no new image is uploaded
    }

    // Correctly formatted SQL query
    $updateQuery = "UPDATE items SET name='$name', price='$price', description='$description', category='$category', quantity='$quantity', image='$image' WHERE id=$id";
    if ($conn->query($updateQuery) === TRUE) {
        header('Location: inventory.php'); // Redirect back to inventory page
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Item</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-6">
        <h1 class="text-2xl font-bold mb-4">Edit Item</h1>
        <form method="POST" enctype="multipart/form-data">
            <!-- Form fields for editing the item -->
            <div class="mb-4">
                <label class="block text-gray-700">Name</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($item['name']); ?>" class="w-full p-2 border rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Price</label>
                <input type="text" name="price" value="<?php echo htmlspecialchars($item['price']); ?>" class="w-full p-2 border rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Description</label>
                <textarea name="description" class="w-full p-2 border rounded"><?php echo htmlspecialchars($item['description']); ?></textarea>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Category</label>
                <input type="text" name="category" value="<?php echo htmlspecialchars($item['category']); ?>" class="w-full p-2 border rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Quantity</label>
                <input type="text" name="quantity" value="<?php echo htmlspecialchars($item['quantity']); ?>" class="w-full p-2 border rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700">Image</label>
                <input type="file" name="image" class="w-full p-2 border rounded">
                <?php if (!empty($item['image'])): ?>
                    <p class="mt-2">Current Image:</p>
                    <img src="uploads/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="w-24 h-24 object-cover mt-2">
                <?php endif; ?>
                <p class="mt-2 text-sm text-gray-600">Leave blank to keep the current image.</p>
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Update Item</button>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
