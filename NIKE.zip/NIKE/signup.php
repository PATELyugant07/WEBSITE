<?php
// signup.php

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $hashed_password);

    if ($stmt->execute()) {
        header("Location: login.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <!-- Include Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="h-screen flex justify-center items-center bg-cover bg-center" style="background-image: url('img/281055.jpg');">
    <div class="bg-black bg-opacity-50 p-8 rounded-lg shadow-lg max-w-sm w-full">
        <h2 class="text-2xl font-bold text-center mb-6 text-yellow-500">Signup</h2>
        <form action="signup.php" method="POST" class="flex flex-col">
            <label for="username" class="mb-2 font-medium text-white">Username:</label>
            <input type="text" id="username" name="username" required class="mb-4 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            <label for="email" class="mb-2 font-medium text-white">Email:</label>
            <input type="email" id="email" name="email" required class="mb-4 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            <label for="password" class="mb-2 font-medium text-white">Password:</label>
            <input type="password" id="password" name="password" required class="mb-4 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            <button type="submit" class="bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition-colors">Sign Up</button>
        </form>
        <a href="login.php" class="block text-center mt-4 text-blue-500 hover:underline">Already have an account? Login here.</a>
    </div>
</body>
</html>
