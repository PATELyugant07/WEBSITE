<?php
session_start();

// Function to handle redirection based on user role
function redirectToAppropriatePage() {
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];
        
        if ($username === 'admin') {
            header("Location: adminpage.php");
            exit();
        } else {
            header("Location: userpage.php");
            exit();
        }
    }
}

// Handle redirection if "Dashboard" button is clicked
if (isset($_GET['redirect']) && $_GET['redirect'] === 'dashboard') {
    redirectToAppropriatePage();
}

// Handle logout functionality
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header("Location: Home.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root"; // Change to your database username
$password = ""; // Change to your database password
$dbname = "website"; // Change to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch items from the database
$sql = "SELECT * FROM items";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIKE</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .ticker-wrapper {
            overflow: hidden;
            position: relative;
            height: 2rem; /* Adjust height as needed */
        }
        
        .ticker-content {
            display: flex;
            white-space: nowrap;
            animation: scroll-left 30s linear infinite;
            position: absolute;
            width: 80%;
        }
        
        .ticker-item {
            padding: 0 2rem; /* Adjust spacing as needed */
        }

        @keyframes scroll-left {
            0% {
                transform: translateX(100%);
            }
            100% {
                transform: translateX(-100%);
            }
        }
        .card {
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body class="bg-gray-80 flex flex-col min-h-screen">

    <!-- Secondary Navigation Bar -->
    <nav class="bg-gray-200 text-gray-800">
        <div class="max-w-screen-xl mx-auto flex justify-between items-center ">
            <!-- Logo -->
            <a href="Home.php">
                <img src="img/Air-Jordan-Logo-1.png" alt="Logo" class="h-10 w-auto">
            </a>
            <!-- Navigation Links -->
            <ul class="hidden md:flex space-x-6">
                <li><a href="#" class="hover:text-gray-600">Find a Store</a></li>
                <li><a href="help.php" class="hover:text-gray-600">Help</a></li>
                <li><a href="join.php" class="hover:text-gray-600">Join Us</a></li>
            </ul>
            <div class="flex space-x-6 items-center">
                <form action="search.php" method="get" class="flex items-center">
                    <input type="text" name="query" placeholder="Search..." class="px-2 py-1 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-gray-400">
                    <button type="submit" class="bg-gray-800 text-white px-3 py-1 rounded-r-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-400">
                        <i class="fas fa-search text-xl"></i>
                    </button>
                </form>
                <a href="cart.php" class="text-gray-800 hover:text-gray-600">
                    <i class="fas fa-shopping-cart text-xl"></i>
                </a>
                <a href="about.php" class="hover:text-gray-600">About</a>
                <a href="contact.php" class="hover:text-gray-600">Contact</a>
            </div>
        </div>
    </nav>
    
    <!-- Main Navigation Bar -->
    <header class="bg-white shadow-md">
        <nav class="flex items-center p-2 max-w-screen-xl mx-auto">
            <!-- Logo -->
            <a href="Home.php" class="flex-shrink-0">
                <img src="img/th.jpeg" alt="NIKE Logo" class="h-10 w-auto">
            </a>
            
            <!-- Navigation Links -->
            <ul class="hidden md:flex flex-grow justify-center space-x-6 mx-6">
                <li><a href="Home.php" class="text-gray-800 hover:text-gray-600">New & Featured</a></li>
                <li><a href="men.php" class="text-gray-800 hover:text-gray-600">Products</a></li>
                <li><a href="snkr.php" class="text-gray-800 hover:text-gray-600">SNKR</a></li>
            </ul>
            
            <!-- Authentication Buttons -->
            <div class="flex-shrink-0 space-x-4">
                <?php if (isset($_SESSION['username'])): ?>
                    <a href="?redirect=dashboard"><button class="bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-110 hover:bg-gray-700">Dashboard</button></a>
                    <a href="?action=logout"><button class="bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-110 hover:bg-gray-700">Logout</button></a>
                <?php else: ?>
                    <a href="./signup.php"><button class="bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-110 hover:bg-gray-700">Sign Up</button></a>
                    <a href="./login.php"><button class="bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-110 hover:bg-gray-700">Login</button></a>
                <?php endif; ?>
            </div>
        </nav>
    </header>
    <main class="flex-1">

<!-- News Ticker -->
<section class="bg-gray-300 text-black py-2">
    <div class="ticker-wrapper">
        <div class="ticker-content">
            <span class="ticker-item">Exclusive Offer: Save 25% on your next purchase! Limited time only!</span>
            <span class="ticker-item">New Arrivals: Discover the latest trends in our new spring collection!</span>
            <span class="ticker-item">Update: We’re launching a new eco-friendly product line. Stay tuned for more details!</span>
            <span class="ticker-item">Limited Time Offer: Get a free gift with every purchase over $80!</span>
            <span class="ticker-item">Hot New Styles: Update your wardrobe with our fresh, cutting-edge designs for this season.</span>
            <span class="ticker-item">News Flash: Our athletes are gearing up for the upcoming championship. Follow their journey with us!</span>
        </div>
    </div>
</section>


</main>

    <!-- Main Content -->
    <main class="flex-1 p-6">
       
        
        <section>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <div class="bg-white p-6 rounded-lg shadow-md card">
    <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" class="w-full h-50 object-cover mb-2 rounded-t-lg">
    <h2 class="text-xl font-semibold mb-2"><?php echo htmlspecialchars($row['name']); ?></h2>
    <p class="text-gray-700 mb-2"><?php echo htmlspecialchars($row['description']); ?></p>
    <p class="text-gray-900 font-bold mb-4">$<?php echo htmlspecialchars($row['price']); ?></p>
    <a href="purchase.php?item_id=<?php echo htmlspecialchars($row['id']); ?>" class="inline-block bg-gray-800 text-white px-4 py-2 rounded-full font-bold transition-transform transform hover:scale-110 hover:bg-gray-700">Buy Now</a>

</div>


                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No items found.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <footer class="bg-gray-300 text-black py-4 border-t border-gray-300">
        <div class="max-w-screen-xl mx-auto">
            <!-- Footer Top Section -->
            <div class="flex justify-between items-center mb-4">
                <ul class="flex space-x-4">
                <li><a href="Home.php" class="text-gray-800 hover:text-gray-600">New & Featured</a></li>
                <li><a href="men.php" class="text-gray-800 hover:text-gray-600">Products</a></li>
                </ul>
                <div class="flex space-x-4">
                    <a href="https://www.instagram.com" target="_blank" class="hover:text-gray-600"><i class="fab fa-instagram text-xl"></i></a>
                    <a href="https://play.google.com" target="_blank" class="hover:text-gray-600"><i class="fab fa-google-play text-xl"></i></a>
                    <a href="https://www.facebook.com" target="_blank" class="hover:text-gray-600"><i class="fab fa-facebook-f text-xl"></i></a>
                </div>
            </div>

            <!-- Footer Bottom Section -->
            <p class="text-center text-sm">&copy; 2024 NIKE. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
