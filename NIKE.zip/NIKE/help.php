<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help Page</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <!-- Header Section -->
    <header class="bg-blue-600 text-white py-6">
        <div class="container mx-auto text-center">
            <h1 class="text-4xl font-bold">How Can We Help You?</h1>
            <p class="text-lg mt-2">Find answers, get support, and explore our resources.</p>
        </div>
    </header>

    <!-- Search Bar -->
    <section class="py-10 bg-white">
        <div class="container mx-auto">
            <div class="max-w-3xl mx-auto">
                <input type="text" class="w-full p-4 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Search for help topics...">
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-16 bg-gray-50">
        <div class="container mx-auto">
            <h2 class="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
            <div class="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- FAQ 1 -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h3 class="text-xl font-semibold mb-4">How do I reset my password?</h3>
                    <p class="text-gray-600">To reset your password, go to the login page, click on "Forgot Password," and follow the instructions to reset your password via email.</p>
                </div>
                <!-- FAQ 2 -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h3 class="text-xl font-semibold mb-4">How can I update my account information?</h3>
                    <p class="text-gray-600">You can update your account information by visiting your profile page and clicking on "Edit Profile."</p>
                </div>
                <!-- FAQ 3 -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h3 class="text-xl font-semibold mb-4">What is your refund policy?</h3>
                    <p class="text-gray-600">Our refund policy allows refunds within 30 days of purchase. Please contact support for more details.</p>
                </div>
                <!-- FAQ 4 -->
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <h3 class="text-xl font-semibold mb-4">How do I contact customer support?</h3>
                    <p class="text-gray-600">You can contact our customer support team by filling out the form below or calling us at 1-800-123-4567.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="py-16 bg-white">
        <div class="container mx-auto">
            <h2 class="text-3xl font-bold text-center mb-12">Contact Us</h2>
            <div class="max-w-2xl mx-auto">
                <!-- Contact Options -->
                <div class="flex justify-between mb-8">
                    <a href="mailto:support@example.com" class="flex items-center space-x-3">
                        <i class="fas fa-envelope text-2xl text-blue-500"></i>
                        <span>Email Us: support@example.com</span>
                    </a>
                    <a href="tel:18001234567" class="flex items-center space-x-3">
                        <i class="fas fa-phone-alt text-2xl text-green-500"></i>
                        <span>Call Us: 1-800-123-4567</span>
                    </a>
                </div>

                <!-- Support Form -->
                <form class="bg-gray-50 p-6 rounded-lg shadow-md">
                    <div class="mb-4">
                        <label for="name" class="block text-sm font-medium text-gray-700">Your Name</label>
                        <input type="text" id="name" class="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter your name">
                    </div>
                    <div class="mb-4">
                        <label for="email" class="block text-sm font-medium text-gray-700">Your Email</label>
                        <input type="email" id="email" class="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter your email">
                    </div>
                    <div class="mb-4">
                        <label for="message" class="block text-sm font-medium text-gray-700">Your Message</label>
                        <textarea id="message" class="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" rows="4" placeholder="Enter your message"></textarea>
                    </div>
                    <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition duration-300">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-blue-600 text-white py-6 mt-16">
        <div class="container mx-auto text-center">
            <p>&copy; 2024 Your Company Name. All rights reserved.</p>
        </div>
    </footer>

    <!-- Include Font Awesome for Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</body>
</html>
