<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order_id = intval($_POST['order_id']);

    // Delete order from the database
    $sql = "DELETE FROM purchases WHERE item_id = ? AND username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('is', $order_id, $_SESSION['username']);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Order deleted successfully.";
    } else {
        $_SESSION['message'] = "Error: " . $stmt->error;
    }
    $stmt->close();
} else {
    $_SESSION['message'] = "Invalid request.";
}

$conn->close();

// Redirect to the order display page with the message
header("Location: displayorder.php");
exit();
?>
