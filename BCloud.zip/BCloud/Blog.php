<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title>BCloud</title>

  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    html, body {
      overflow-x: hidden;
    }

    /* Smooth transition for mobile menu */
    #mobile-menu {
      transition: max-height 0.3s ease-in-out;
    }

    /* Responsive text and image sizes */
    @media (max-width: 639px) {
      #next-section h3 {
        font-size: 1.125rem;
      }
      #next-section img {
        max-width: 80%;
      }
    }

    @media (min-width: 640px) and (max-width: 767px) {
      #next-section h3 {
        font-size: 1.25rem;
      }
      #next-section img {
        max-width: 90%;
      }
    }

    @media (min-width: 768px) {
      #next-section h3 {
        font-size: 1.5rem;
      }
      #next-section img {
        max-width: 100%;
      }
    }
  </style>
</head>
<body class="bg-gray-100">
<nav class="fixed top-0 left-0 right-0 bg-white shadow-md z-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between h-16 items-center">

      <!-- Logo -->
      <div class="flex items-center">
        <h1 class="text-3xl md:text-5xl font-bold text-blue-500">BCloud</h1>
      </div>

      <!-- Desktop Menu -->
      <div class="hidden md:flex space-x-6 items-center">
        <a href="Home.html" class="text-gray-700 hover:text-blue-600">Home</a>

        <!-- Services Dropdown Desktop -->
       <div class="relative" id="desktop-services-dropdown">
  <div class="flex items-center space-x-1">
    <!-- Navigation link -->
    <a href="Services.html" class="text-gray-700 hover:text-blue-600">Services</a>

    <!-- Dropdown toggle -->
    <button id="desktop-services-toggle"
            class="text-gray-700 hover:text-blue-600 focus:outline-none">
      <svg id="desktop-services-icon" class="w-4 h-4 text-gray-700 transition-transform" fill="none" stroke="currentColor" stroke-width="2"
           viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
        <path d="M6 9l6 6 6-6" />
      </svg>
    </button>
  </div>

  <!-- Dropdown menu -->
  <div id="desktop-services-menu" 
       class="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg opacity-0 invisible transition-opacity duration-200 z-50 pointer-events-none">
     <a href="DataSolution.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-100">Data Solution</a>
    <a href="CloudMigrationStrategy.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-100">Cloud Migration Strategy</a>
    <a href="BusinessIntelligence.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-100">Business Intelligence</a>
    <a href="ManagedServices.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-100">Managed Services</a>
    <a href="StaffAugmentation.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-100">Staff Augmentation</a>
    <a href="Training.html" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-100">Training</a>
  </div>
</div>


        <a href="AboutUs.html" class="text-gray-700 hover:text-blue-600">About Us</a>
        <a href="Blog.html" class="text-gray-700 hover:text-blue-600">Blog</a>
        <a href="Careers.html" class="text-gray-700 hover:text-blue-600">Careers</a>
        <a href="ContactUs.html" class="text-gray-700 hover:text-blue-600">Contact Us</a>

        <!-- Search Icon -->
        <button class="text-gray-700 hover:text-blue-600 focus:outline-none">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2"
            viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </button>
      </div>

      <!-- Mobile Buttons -->
      <div class="md:hidden flex items-center space-x-3">
        <!-- Search Icon for Mobile -->
        <button class="text-gray-700 hover:text-blue-600 focus:outline-none">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2"
            viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </button>

        <!-- Hamburger Menu Toggle -->
        <button id="menu-toggle" aria-label="Toggle menu" class="text-gray-700 focus:outline-none">
          <svg class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2"
            viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
    </div>
  </div>

  <!-- Mobile Menu -->
  <div id="mobile-menu" class="md:hidden hidden px-4 pb-4 transition duration-300 ease-in-out transform origin-top">
  <a href="Home.html" class="block py-2 text-gray-700 hover:text-blue-600">Home</a>

    <!-- Mobile Services Dropdown -->
    <div>
      <button id="mobile-services-toggle"
        class="w-full text-left py-2 flex justify-between items-center text-gray-700 hover:text-blue-600 focus:outline-none">
        <span>Services</span>
        <svg id="mobile-services-icon" class="w-4 h-4 transition-transform duration-200" fill="none" stroke="currentColor" stroke-width="2"
          viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
          <path d="M6 9l6 6 6-6" />
        </svg>
      </button>
      <div id="mobile-services-menu" class="hidden pl-4 mt-1 space-y-1">
         <a href="DataSolution.html" class="block py-1 text-gray-700 hover:text-blue-600">Data Solution</a>
        <a href="CloudMigrationStrategy.html" class="block py-1 text-gray-700 hover:text-blue-600">Cloud Migration Strategy</a>
        <a href="BusinessIntelligence.html" class="block py-1 text-gray-700 hover:text-blue-600">Business Intelligence</a>
        <a href="ManagedServices.html" class="block py-1 text-gray-700 hover:text-blue-600">Managed Services</a>
        <a href="StaffAugmentation.html" class="block py-1 text-gray-700 hover:text-blue-600">Staff Augmentation</a>
        <a href="Training.html" class="block py-1 text-gray-700 hover:text-blue-600">Training</a>
      </div>
    </div>

    <a href="AboutUs.html" class="block py-2 text-gray-700 hover:text-blue-600">About Us</a>
    <a href="Blog.html" class="block py-2 text-gray-700 hover:text-blue-600">Blog</a>
    <a href="Careers.html" class="block py-2 text-gray-700 hover:text-blue-600">Careers</a>
    <a href="ContactUs.html" class="block py-2 text-gray-700 hover:text-blue-600">Contact Us</a>
  </div>
</nav>

<script>
  // Mobile menu toggle
  const menuToggle = document.getElementById('menu-toggle');
  const mobileMenu = document.getElementById('mobile-menu');

  menuToggle.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
    mobileMenu.classList.toggle('scale-y-100');
  });

  // Mobile Services dropdown toggle
  const mobileServicesToggle = document.getElementById('mobile-services-toggle');
  const mobileServicesMenu = document.getElementById('mobile-services-menu');
  const mobileServicesIcon = document.getElementById('mobile-services-icon');

  mobileServicesToggle.addEventListener('click', () => {
    mobileServicesMenu.classList.toggle('hidden');
    mobileServicesIcon.classList.toggle('rotate-180');
  });

  // Desktop Services dropdown toggle
  const desktopServicesToggle = document.getElementById('desktop-services-toggle');
  const desktopServicesMenu = document.getElementById('desktop-services-menu');
  const desktopServicesIcon = document.getElementById('desktop-services-icon');

  desktopServicesToggle.addEventListener('click', (e) => {
    e.preventDefault();
    const isHidden = desktopServicesMenu.classList.contains('invisible');

    if (isHidden) {
      desktopServicesMenu.classList.remove('invisible', 'opacity-0', 'pointer-events-none');
      desktopServicesMenu.classList.add('opacity-100', 'pointer-events-auto');
      desktopServicesIcon.classList.add('rotate-180');
    } else {
      desktopServicesMenu.classList.add('invisible', 'opacity-0', 'pointer-events-none');
      desktopServicesMenu.classList.remove('opacity-100', 'pointer-events-auto');
      desktopServicesIcon.classList.remove('rotate-180');
    }
  });

  // Close desktop dropdown if clicking outside
  document.addEventListener('click', (event) => {
    const isClickInside = desktopServicesToggle.contains(event.target) || desktopServicesMenu.contains(event.target);
    if (!isClickInside) {
      desktopServicesMenu.classList.add('invisible', 'opacity-0', 'pointer-events-none');
      desktopServicesMenu.classList.remove('opacity-100', 'pointer-events-auto');
      desktopServicesIcon.classList.remove('rotate-180');
    }
  });
</script>
<section id="career" class="relative bg-cover bg-center bg-fixed h-[700px]" style="background-image: url('a6.jpg');">
  <!-- Overlay -->
  <div class="absolute inset-0 bg-black bg-opacity-60"></div>

  <!-- Centered Content -->
  <div class="relative z-10 flex flex-col items-center justify-center h-full w-full px-4 text-center">
    <h1 class="text-white text-5xl md:text-6xl font-bold  mb-6">
      Blog
    </h1>
   
  </div>
</section>

  <!-- Footer -->
<footer class="bg-blue-900 text-gray-100 pt-10 pb-6">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">

      <!-- Company Info -->
      <div>
        <h1 class="text-2xl font-bold text-white mb-2">BCloud</h1>
        <p class="text-sm text-gray-300">BCloud Global Services: Global expertise in IT Consulting for businesses. Your pathway to growth and excellence.</p>
      </div>

      <!-- Navigation Links -->
      <div>
        <h2 class="text-lg font-semibold mb-3 text-white">Company</h2>
        <ul class="space-y-2">
          <li><a href="About.html" class="hover:text-blue-300 transition">About Us</a></li>
          <li><a href="Services.html" class="hover:text-blue-300 transition">Services</a></li>
          <li><a href="Careers.html" class="hover:text-blue-300 transition">Careers</a></li>
        </ul>
      </div>

      <!-- Contact Info -->
      <div>
        <h2 class="text-lg font-semibold mb-3 text-white">Contact Us</h2>
        <ul class="space-y-2 text-sm text-gray-300">
          <li>
            <strong>Mail:</strong>
            <a href="mailto:hr@bcloudglobalservices.com" class="hover:text-blue-300"> hr@bcloudglobalservices.com</a>
          </li>
          <li>
            <strong>Phone:</strong>
            <a href="tel:+918556900901" class="hover:text-blue-300"> +91-85569 00901</a>
          </li>
        </ul>
        <div class="mt-4">
    <a href="admin_login.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded transition duration-300">
      Admin Login
    </a>
  </div>
      </div>

    </div>
    

    <!-- Divider -->
    <div class="border-t border-blue-700 mt-10 pt-4 text-center text-sm text-gray-400">
      &copy; 2025 BCloud Global Services. All rights reserved.
    </div>
  </div>
</footer>

</body>
</html>
